import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, catchError, forkJoin, from, map, switchMap, throwError } from "rxjs";
import { AuthService } from "../auth/auth.service";
import { environment } from "../../../environments/environment";
import { ReservationDto } from "../reservation/reservation.model";
import { ensureCsvBlob } from "../../utils/file-download.util";
import { PatientFinanceDetails } from "../../shared/patient-finance/patient-finance-details.models";

export interface ApiCommandResponse<T = unknown> {
  isSuccess: boolean;
  message: string;
  data?: T;
}

export type LeadAssignmentSourceType = 1 | 2;
export interface LeadAssignmentSettingResponse {
  assignmentSourceType: LeadAssignmentSourceType;
  updatedAt?: string | null;
}

export interface PaginatedResponse<T> {
  items: T[];
  totalCount: number;
  pageNumber: number;
  pageSize: number;
  totalPages: number;
  raw?: unknown;
  source?: unknown;
}

export interface AdminUser {
  id: string;
  Id?: string;
  firstName: string;
  FirstName?: string;
  lastName: string;
  LastName?: string;
  phoneNumber: string;
  PhoneNumber?: string;
  roleName: string;
  RoleName?: string;
  isActive: boolean;
  IsActive?: boolean;
  isCompleteProfile?: boolean;
  IsCompleteProfile?: boolean;
  lastSeenAt?: string | null;
  LastSeenAt?: string | null;
  createdAt?: string;
  CreatedAt?: string;
  gender?: number;
  Gender?: number;
  avatarImageName?: string | null;
  AvatarImageName?: string | null;
  profileId?: number;
  ProfileId?: number;
  consultantProfileId?: number;
  ConsultantProfileId?: number;
  consultantIsOnline?: boolean | null;
  ConsultantIsOnline?: boolean | null;
  consultantIsAvailable?: boolean | null;
  ConsultantIsAvailable?: boolean | null;
  secretaryType?: number | string | null;
  SecretaryType?: number | string | null;
  secretaryAccessSchedules?: SecretaryAccessSchedule[];
  SecretaryAccessSchedules?: SecretaryAccessSchedule[];
  secretaryAccessPermissions?: SecretaryAccessPermission[];
  SecretaryAccessPermissions?: SecretaryAccessPermission[];
}

export enum SecretaryType {
  Main = 1,
  Assistant = 2,
}

export enum SecretaryPermissionType {
  ViewReservations = 1,
  EditReservations = 2,
  ConfirmAttendance = 3,
  SecretaryAnnouncement = 4,
  ViewPatients = 5,
  CreateReservation = 6,
  CancelReservation = 7,
}

export interface SecretaryAccessSchedule {
  dayOfWeek: number;
  isActive: boolean;
}

export interface SecretaryAccessPermission {
  dayOfWeek: number;
  permissionType: SecretaryPermissionType;
  isActive: boolean;
}

export interface SaveUserRequest {
  id?: string;
  firstName: string;
  lastName: string;
  phoneNumber: string;
  passwordHash?: string;
  isCompleteProfile: boolean;
  avatarImageName: string | null;
  gender: number;
  birthDate?: string;
  isActive?: boolean;
  roleName: string;
  secretaryType?: SecretaryType;
  secretaryAccessSchedules?: SecretaryAccessSchedule[];
  secretaryAccessPermissions?: SecretaryAccessPermission[];
}

export interface UserFilters {
  firstName?: string;
  lastName?: string;
  roleName?: string;
  phoneNumber?: string;
  gender?: number | null;
  isActive?: boolean | null;
  pageNumber: number;
  pageSize: number;
}

export interface SecretaryFilters {
  search?: string;
  firstName?: string;
  lastName?: string;
  phoneNumber?: string;
  secretaryType?: SecretaryType | null;
  pageNumber: number;
  pageSize: number;
}

export interface SecretaryDayPermissions {
  day: string;
  permissions: SecretaryPermissionType[];
}

export interface SecretarySchedule {
  secretaryType: SecretaryType;
  dayPermissions: SecretaryDayPermissions[];
}

export interface Consultant {
  id: string;
  Id?: string;
  firstName: string;
  FirstName?: string;
  lastName: string;
  LastName?: string;
  phoneNumber: string;
  PhoneNumber?: string;
  profileId: number;
  ProfileId?: number;
  todayReservationsCount?: number;
  TodayReservationsCount?: number;
  lastSeenAt?: string | null;
  LastSeenAt?: string | null;
  consultantIsOnline?: boolean | null;
  ConsultantIsOnline?: boolean | null;
  consultantIsAvailable?: boolean | null;
  ConsultantIsAvailable?: boolean | null;
  attendanceResponse?: unknown;
  scoreLogResponse?: unknown;
  leadsAssignmentItemsResponse?: unknown;
}

export interface ConsultantFilters {
  firstName?: string;
  lastName?: string;
  phoneNumber?: string;
  pageNumber: number;
  pageSize: number;
}

export interface ConsultantLimitUpdate {
  limitNumber?: number | null;
  LimitNumber?: number | null;
  effectiveDailyLimit: number;
  EffectiveDailyLimit?: number;
  todayPickupCount: number;
  TodayPickupCount?: number;
}

export interface AdminConsultantProfile {
  profileId: number;
  ProfileId?: number;
  userId: string;
  UserId?: string;
  firstName: string;
  FirstName?: string;
  lastName: string;
  LastName?: string;
  phoneNumber: string;
  PhoneNumber?: string;
  userIsActive: boolean;
  UserIsActive?: boolean;
  userIsCompleteProfile: boolean;
  UserIsCompleteProfile?: boolean;
  nationalCode: string;
  NationalCode?: string;
  address: string;
  Address?: string;
  isAvailable: boolean;
  IsAvailable?: boolean;
  isOnline: boolean;
  IsOnline?: boolean;
  isCompleteProfile: boolean;
  IsCompleteProfile?: boolean;
  workStartTime?: string | null;
  WorkStartTime?: string | null;
  workEndTime?: string | null;
  WorkEndTime?: string | null;
  notes?: string | null;
  Notes?: string | null;
  lastOnlineAt?: string | null;
  LastOnlineAt?: string | null;
  lastOfflineAt?: string | null;
  LastOfflineAt?: string | null;
  limitNumber?: number | null;
  LimitNumber?: number | null;
  effectiveDailyLimit: number;
  EffectiveDailyLimit?: number;
  todayPickupCount: number;
  TodayPickupCount?: number;
}

export interface AttendanceItem {
  id: number;
  attendanceDate: string;
  checkInTime: string;
  checkOutTime: string;
  status: number;
  description: string | null;
}

export interface LeadAssignmentItem {
  id?: number;
  Id?: number;
  leadAssignmentId?: number;
  LeadAssignmentId?: number;
  userName?: string | null;
  UserName?: string | null;
  fullName?: string | null;
  FullName?: string | null;
  firstName?: string | null;
  FirstName?: string | null;
  lastName?: string | null;
  LastName?: string | null;
  phoneNumber?: string | null;
  PhoneNumber?: string | null;
  mobile?: string | null;
  Mobile?: string | null;
  userPhoneNumber?: string | null;
  UserPhoneNumber?: string | null;
  leadPhoneNumber?: string | null;
  LeadPhoneNumber?: string | null;
  leadAssignmentState?: number | null;
  LeadAssignmentState?: number | null;
  state?: number | null;
  State?: number | null;
  status?: number | null;
  Status?: number | null;
  leadAssignmentType?: number | null;
  LeadAssignmentType?: number | null;
  type?: number | null;
  Type?: number | null;
  assignmentType?: number | null;
  AssignmentType?: number | null;
  user?: LeadPerson | null;
  User?: LeadPerson | null;
  lead?: LeadPerson | null;
  Lead?: LeadPerson | null;
  createdAt?: string | null;
  CreatedAt?: string | null;
  contactedAt?: string | null;
  ContactedAt?: string | null;
  assignedAt?: string | null;
  AssignedAt?: string | null;
}

export interface ConsultantDailySummaryItem {
  consultantProfileId: number;
  ConsultantProfileId?: number;
  firstName: string;
  FirstName?: string;
  lastName: string;
  LastName?: string;
  phoneNumber: string;
  PhoneNumber?: string;
  todayReservationsCount: number;
  TodayReservationsCount?: number;
}

export interface ConsultantsDailySummaryResponse {
  date: string;
  items: ConsultantDailySummaryItem[];
}

export interface LeadCallReportExportFilters {
  from?: string;
  to?: string;
}

export interface LeadsReportFilters {
  from?: string;
  to?: string;
  consultantProfileId?: number;
  leadAssignmentState?: number;
  assignmentType?: number;
  callResult?: number;
  isAssigned?: boolean;
  hasCalled?: boolean;
  hasSubmittedReport?: boolean;
  pageNumber: number;
  pageSize: number;
}

export interface LeadsReportSummary {
  total: number;
  assigned: number;
  unassigned: number;
  called: number;
  notCalled: number;
  converted: number;
  withSubmittedReport: number;
}

export interface LeadsReportItem {
  leadId: number;
  leadName: string;
  leadPhoneNumber: string;
  secondaryPhoneNumber: string | null;
  leadAssignmentState: number;
  leadAssignmentStateTitle: string;
  assignmentType: number | null;
  assignmentTypeTitle: string | null;
  consultantProfileId: number | null;
  consultantFullName: string | null;
  consultantPhoneNumber: string | null;
  isAssigned: boolean;
  hasCalled: boolean;
  callResult: number | null;
  callResultTitle: string | null;
  reportDescription: string | null;
  assignedAt: string | null;
  assignedAtPersian: string | null;
  contactedAt: string | null;
  contactedAtPersian: string | null;
  reportSubmittedAt: string | null;
  reportSubmittedAtPersian: string | null;
  createdAt: string;
  createdAtPersian: string | null;
  patientCity: string | null;
  patientRegion: string | null;
  businessName: string | null;
  attendanceProbabilityPercent: number | null;
}

export interface LeadsReportResponse extends PaginatedResponse<LeadsReportItem> {
  summary: LeadsReportSummary;
}

export interface DailyReservationsReportFilters {
  date?: string;
  reservationOwnerType?: "Consultant" | "Secretary";
  consultantProfileId?: number;
  secretaryUserId?: string;
  requestStatus?: number;
  includeAll?: boolean;
}

export interface DailyReservationsSummary {
  total: number;
  active: number;
  canceled: number;
  pendingSecretaryReview: number;
  confirmed: number;
  rejected: number;
  uniqueConsultants: number;
}

export interface DailyReservationReportItem {
  reservationId: number;
  leadAssignmentId: number;
  consultantProfileId: number;
  consultantFullName: string;
  consultantPhoneNumber: string;
  patientName: string;
  patientCount?: number | null;
  patientPhoneNumber: string;
  secondaryPhoneNumber: string | null;
  patientCity: string | null;
  patientRegion: string | null;
  businessName: string | null;
  attendanceProbabilityPercent: number | null;
  reservationAt: string;
  appointmentDateTimePersian?: string | null;
  createdAt: string;
  createdAtPersian?: string | null;
  requestStatus: number;
  requestStatusTitle: string;
  visitResultStatus: number;
  visitResultStatusTitle: string;
  isConfirmedWithPatient: boolean;
  isCanceled: boolean;
  cancellationReason: string | null;
  description: string | null;
  secretaryAnnouncement?: string | null;
  SecretaryAnnouncement?: string | null;
  secretaryAnnouncementDescription?: string | null;
  SecretaryAnnouncementDescription?: string | null;
  secretaryAnnouncementStatus?: string | null;
  SecretaryAnnouncementStatus?: string | null;
  dentalServices?: number[] | null;
  DentalServices?: number[] | null;
}

export interface DailyReservationsReport {
  date: string;
  datePersian?: string | null;
  generatedAt: string;
  generatedAtPersian?: string | null;
  summary: DailyReservationsSummary;
  items: DailyReservationReportItem[];
}

export interface PatientFinanceReportFilters {
  search?: string;
  patientName?: string;
  fileNumber?: number;
  serviceId?: number;
  agreementType?: number;
  status?: number;
  fromDate?: string;
  toDate?: string;
  page: number;
  pageSize: number;
}

export interface AdminPatientFinanceFile {
  id: number;
  fileNumber: number;
  firstName: string;
  lastName: string;
  phoneNumber: string;
  finance: PatientFinanceDetails | null;
}

export interface PatientFinanceReportItem {
  chequeDates?: string[];
  chequeRegistrations?: string[];
  balanceAmount: number;
  chequeDate?: string | null;
  chequeRegistration?: string | null;
  paymentMethod?: string | null;
  installmentStatus?: string | null;
  guaranteeDocument?: string | null;
  notes?: string | null;
  consultantName?: string | null;
  toothUnitCount?: number | null;
  caseId: string;
  patientId: string;
  patientName: string;
  phoneNumber: string;
  fileNumber: string;
  serviceIds: number[];
  serviceNames: string[];
  totalAmount: number;
  prePaymentAmount: number;
  depositAmount: number;
  paidAmount: number;
  remainingAmount: number;
  unpaidDebtAmount: number;
  chequeAmount: number;
  promissoryNoteAmount: number;
  agreementType: number;
  status: number;
  createdBy: string;
  createdAt: string;
}

export interface PatientFinanceReportSummary {
  caseCount: number;
  totalAmount: number;
  prePaymentAmount: number;
  depositAmount: number;
  paidAmount: number;
  remainingAmount: number;
  unpaidDebtAmount: number;
  chequeAmount: number;
  promissoryNoteAmount: number;
}

export interface PatientFinanceReportResponse {
  items: PatientFinanceReportItem[];
  totalCount: number;
  pageNumber: number;
  pageSize: number;
  summary: PatientFinanceReportSummary;
}

export interface UpdatePatientFinanceRequest {
  paymentMethod?: string | null;
  installmentStatus?: string | null;
  guaranteeDocument?: string | null;
  notes?: string | null;
  consultantName?: string | null;
  toothUnitCount?: number | null;
  totalAmount: number;
  prePaymentAmount: number;
  depositAmount: number;
  agreementType: number;
}

export interface AdminPatientCheque { id: number; amount: number; sayadNumber: string; ownerName: string; dueDate: string; status: number; }
export interface AdminPatientPromissoryNote { id: number; amount: number; serialNumber: string; dueDate: string; status: number; }
export interface AdminFinancialCaseDto {
  id: string;
  guaranteeDocument?: string | null;
  paymentMethod?: string | null;
  installmentStatus?: string | null;
  notes?: string | null;
  consultantName?: string | null;
  toothUnitCount?: number | null;
  patientId: string;
  patientName: string;
  patientFileNumber?: string | null;
  patientPhoneNumber?: string | null;
  serviceIds: number[];
  serviceNames: string[];
  totalAmount: number;
  prePaymentAmount: number;
  depositAmount: number;
  totalPaidAmount: number;
  remainingAmount: number;
  totalDebtAmount: number;
  balanceAmount: number;
  agreementType: number;
  status: number;
  createdAt: string;
  chequeDates?: string[];
  chequeRegistrations?: string[];
}

export interface AdminPatientFinanceDetails {
  case: AdminFinancialCaseDto;
  chequeCount: number;
  chequeAmount: number;
  promissoryNoteCount: number;
  promissoryNoteAmount: number;
  cheques?: AdminPatientCheque[];
  promissoryNotes?: AdminPatientPromissoryNote[];
}
export interface UpdateAdminChequeRequest { amount: number; sayadNumber: string; ownerName: string; dueDate: string; }
export interface UpdateAdminPromissoryNoteRequest { amount: number; serialNumber: string; dueDate: string; }

export interface AdminLeadSheet { id: number; name: string; isActive: boolean; createdAt: string; }

export interface LeadFilters {
  profileId?: number;
  searchText?: string;
  leadAssignmentState?: number | null;
  leadAssignmentType?: number | null;
  pageNumber: number;
  pageSize: number;
}

export interface SecretaryReservation extends ReservationDto {
  leadAssignmentId?: number;
  LeadAssignmentId?: number;
  consultantProfileId?: number;
  ConsultantProfileId?: number;
  consultantUserId?: string | null;
  ConsultantUserId?: string | null;
  consultantFullName?: string | null;
  ConsultantFullName?: string | null;
  patientUserId?: string | null;
  PatientUserId?: string | null;
  requiresPatientProfile?: boolean;
  RequiresPatientProfile?: boolean;
  patientPhoneNumber?: string | null;
  PatientPhoneNumber?: string | null;
  secondaryPhoneNumber?: string | null;
  SecondaryPhoneNumber?: string | null;
  patientCity?: string | null;
  PatientCity?: string | null;
  patientRegion?: string | null;
  PatientRegion?: string | null;
  businessName?: string | null;
  BusinessName?: string | null;
  attendanceProbabilityPercent?: number | null;
  AttendanceProbabilityPercent?: number | null;
  attendanceConfirmationStatus?: number | null;
  AttendanceConfirmationStatus?: number | null;
  consultantAttendanceConfirmedAt?: string | null;
  ConsultantAttendanceConfirmedAt?: string | null;
  consultantSaysPatientAttended?: boolean | null;
  ConsultantSaysPatientAttended?: boolean | null;
  consultantAttendanceNote?: string | null;
  ConsultantAttendanceNote?: string | null;
  isWaitingForSecretaryReview?: boolean | null;
  IsWaitingForSecretaryReview?: boolean | null;
  secretaryReviewedAt?: string | null;
  SecretaryReviewedAt?: string | null;
  secretaryUserId?: string | null;
  SecretaryUserId?: string | null;
  secretaryApprovedConsultantConfirmation?: boolean | null;
  SecretaryApprovedConsultantConfirmation?: boolean | null;
  secretaryReviewNote?: string | null;
  SecretaryReviewNote?: string | null;
  secretaryAnnouncement?: string | null;
  SecretaryAnnouncement?: string | null;
  secretaryAnnouncementStatus?: string | null;
  SecretaryAnnouncementStatus?: string | null;
  secretaryAnnouncementUpdatedAt?: string | null;
  SecretaryAnnouncementUpdatedAt?: string | null;
  secretaryAnnouncementUserId?: string | null;
  SecretaryAnnouncementUserId?: string | null;
  isAttendanceScoreApplied?: boolean | null;
  IsAttendanceScoreApplied?: boolean | null;
  attendanceScoreValue?: number | null;
  AttendanceScoreValue?: number | null;
  attendanceScoreAppliedAt?: string | null;
  AttendanceScoreAppliedAt?: string | null;
  description?: string | null;
  Description?: string | null;
  isCanceled?: boolean;
  IsCanceled?: boolean;
}

export interface SecretaryReservationFilters {
  consultantProfileId?: number | null;
  date?: string;
  from?: string;
  to?: string;
  searchText?: string;
  attendanceConfirmationStatus?: number | null;
  onlyWaitingForSecretaryReview?: boolean;
  onlyConsultantAttendanceConfirmed?: boolean;
  onlyDue?: boolean;
  includeCanceled?: boolean;
  pageNumber: number;
  pageSize: number;
}

export interface CompletePatientProfileRequest {
  reservationId: number;
  firstName: string;
  lastName: string;
  phoneNumber: string;
  passwordHash: string;
  avatarImageName?: string | null;
  gender: number;
  birthDate: string;
  address: string;
  emergencyPhoneNumber?: string | null;
  insuranceName?: string | null;
  notes?: string | null;
}

export interface CompletePatientProfileResponse {
  reservationId: number;
  patientUserId: string;
  patientProfileId: number;
  leadAssignmentId: number;
  consultantProfileId: number;
  reservationAt: string;
  patientName: string;
  patientPhoneNumber: string;
  isCompleteProfile: boolean;
  roleName: string;
}

export interface ReservationAttendanceReview {
  id?: number;
  Id?: number;
  reservationId?: number;
  ReservationId?: number;
  patientName?: string | null;
  PatientName?: string | null;
  patientPhoneNumber?: string | null;
  PatientPhoneNumber?: string | null;
  patientCity?: string | null;
  PatientCity?: string | null;
  consultantName?: string | null;
  ConsultantName?: string | null;
  reservationAt?: string | null;
  ReservationAt?: string | null;
  attendanceProbabilityPercent?: number | null;
  AttendanceProbabilityPercent?: number | null;
  attendancePrediction?: string | null;
  AttendancePrediction?: string | null;
  attendanceConfirmationStatus?: number | null;
  AttendanceConfirmationStatus?: number | null;
  consultantAttendanceNote?: string | null;
  ConsultantAttendanceNote?: string | null;
}

export interface ReviewAttendanceRequest {
  reservationId: number;
  secretaryUserId: string;
  approved: boolean;
  note: string | null;
}

interface LeadPerson {
  userName?: string | null;
  UserName?: string | null;
  fullName?: string | null;
  FullName?: string | null;
  name?: string | null;
  Name?: string | null;
  firstName?: string | null;
  FirstName?: string | null;
  lastName?: string | null;
  LastName?: string | null;
  phoneNumber?: string | null;
  PhoneNumber?: string | null;
  mobile?: string | null;
  Mobile?: string | null;
}

@Injectable({ providedIn: "root" })
export class AdminDashboardService {
  getAdminLeadSheets(): Observable<AdminLeadSheet[]> {
    return this.http.get<AdminLeadSheet[]>(`${this.apiBaseUrl}/admin/lead-sheets`, { headers: this.authHeaders() });
  }

  createAdminLeadSheet(name: string): Observable<AdminLeadSheet> {
    return this.http.post<AdminLeadSheet>(`${this.apiBaseUrl}/admin/lead-sheets`, { name }, { headers: this.authHeaders() });
  }

  addAdminSheetLead(sheetId: number, lead: { phoneNumber: string; firstName: string; lastName: string }): Observable<unknown> {
    return this.http.post(`${this.apiBaseUrl}/admin/lead-sheets/${sheetId}/leads`, lead, { headers: this.authHeaders() });
  }

  private readonly apiBaseUrl = environment.apiBaseUrl;

  constructor(
    private http: HttpClient,
    private auth: AuthService,
  ) {}

  getLeadAssignmentSetting(): Observable<LeadAssignmentSettingResponse> {
    return this.http.get<unknown>(`${this.apiBaseUrl}/admin/lead-assignment-settings`, {
      headers: this.authHeaders(),
    }).pipe(map((response) => this.unwrap<LeadAssignmentSettingResponse>(response)));
  }

  updateLeadAssignmentSetting(assignmentSourceType: LeadAssignmentSourceType): Observable<LeadAssignmentSettingResponse> {
    return this.http.put<unknown>(`${this.apiBaseUrl}/admin/lead-assignment-settings`, { assignmentSourceType }, {
      headers: this.authHeaders(),
    }).pipe(map((response) => this.unwrap<LeadAssignmentSettingResponse>(response)));
  }

  getUsers(filters: UserFilters): Observable<PaginatedResponse<AdminUser>> {
    return this.http
      .get<unknown>(`${this.apiBaseUrl}/User`, {
        headers: this.authHeaders(),
        params: this.toParams(filters),
      })
      .pipe(
        map((response) =>
          this.normalizePaginatedResponse<AdminUser>(response, filters),
        ),
      );
  }

  getSecretaries(
    filters: SecretaryFilters,
  ): Observable<PaginatedResponse<AdminUser>> {
    return this.http
      .get<unknown>(`${this.apiBaseUrl}/admin/secretaries`, {
        headers: this.authHeaders(),
        params: this.toParams(filters),
      })
      .pipe(
        map((response) =>
          this.normalizePaginatedResponse<AdminUser>(response, filters),
        ),
      );
  }

  getSecretarySchedule(userId: string): Observable<SecretarySchedule> {
    return this.http
      .get<unknown>(`${this.apiBaseUrl}/admin/secretaries/${userId}/schedule`, {
        headers: this.authHeaders(),
      })
      .pipe(map((response) => this.unwrapResponseData(response) as SecretarySchedule));
  }

  updateSecretarySchedule(
    userId: string,
    payload: SecretarySchedule,
  ): Observable<void> {
    return this.http.put<void>(
      `${this.apiBaseUrl}/admin/secretaries/${userId}/schedule`,
      payload,
      { headers: this.authHeaders() },
    );
  }

  addUser(payload: SaveUserRequest): Observable<ApiCommandResponse> {
    return this.http
      .post<ApiCommandResponse>(`${this.apiBaseUrl}/User`, payload, {
        headers: this.authHeaders(),
      })
      .pipe(this.ensureCommandSucceeded("ثبت کاربر انجام نشد"));
  }

  updateUser(payload: SaveUserRequest): Observable<ApiCommandResponse> {
    return this.http
      .put<ApiCommandResponse>(`${this.apiBaseUrl}/User`, payload, {
        headers: this.authHeaders(),
      })
      .pipe(this.ensureCommandSucceeded("ویرایش کاربر انجام نشد"));
  }

  deleteUser(userId: string): Observable<ApiCommandResponse<boolean>> {
    return this.http
      .delete<ApiCommandResponse<boolean>>(`${this.apiBaseUrl}/User/${encodeURIComponent(userId)}`, {
        headers: this.authHeaders(),
      })
      .pipe(this.ensureCommandSucceeded("حذف کاربر انجام نشد"));
  }

  getConsultants(
    filters: ConsultantFilters,
  ): Observable<PaginatedResponse<Consultant>> {
    const userFilters: UserFilters = {
      firstName: filters.firstName,
      lastName: filters.lastName,
      phoneNumber: filters.phoneNumber,
      roleName: "Consultant",
      pageNumber: filters.pageNumber,
      pageSize: filters.pageSize,
    };

    return forkJoin({
      users: this.getUsers(userFilters),
      profiles: this.fetchConsultantProfiles(),
    }).pipe(
      map(({ users, profiles }) => ({
        items: this.mergeConsultantsFromUsers(users.items, profiles.items),
        totalCount: users.totalCount,
        pageNumber: users.pageNumber,
        pageSize: users.pageSize,
        totalPages: users.totalPages,
        raw: { users: users.raw, profiles: profiles.raw },
        source: users.source,
      })),
    );
  }

  getConsultantsList(
    filters: ConsultantFilters = { pageNumber: 1, pageSize: 500 },
  ): Observable<PaginatedResponse<Consultant>> {
    return this.http
      .get<unknown>(`${this.apiBaseUrl}/Consultant/GetConsultants`, {
        headers: this.authHeaders(),
        params: this.toParams(filters),
      })
      .pipe(
        map((response) =>
          this.normalizePaginatedResponse<Consultant>(response, filters),
        ),
        catchError((error) =>
          throwError(() =>
            this.toUserFacingError(error, "دریافت فهرست مشاوران انجام نشد"),
          ),
        ),
      );
  }

  private fetchConsultantProfiles(): Observable<PaginatedResponse<Consultant>> {
    return this.http
      .get<unknown>(`${this.apiBaseUrl}/Consultant/GetConsultants`, {
        headers: this.authHeaders(),
        params: this.toParams({ pageNumber: 1, pageSize: 500 }),
      })
      .pipe(
        map((response) =>
          this.normalizePaginatedResponse<Consultant>(response, {
            pageNumber: 1,
            pageSize: 500,
          }),
        ),
      );
  }

  private mergeConsultantsFromUsers(
    users: AdminUser[],
    profiles: Consultant[],
  ): Consultant[] {
    const profileByUserId = new Map<string, Consultant>();
    const profileByPhone = new Map<string, Consultant>();

    profiles.forEach((profile) => {
      const userId = profile.id || profile.Id || "";
      const phone = profile.phoneNumber || profile.PhoneNumber || "";
      if (userId) profileByUserId.set(userId, profile);
      if (phone) profileByPhone.set(phone, profile);
    });

    return users.map((user) => {
      const userId = user.id || user.Id || "";
      const phone = user.phoneNumber || user.PhoneNumber || "";
      const profile = profileByUserId.get(userId) ?? profileByPhone.get(phone);

      return {
        id: userId,
        firstName: user.firstName || user.FirstName || "",
        lastName: user.lastName || user.LastName || "",
        phoneNumber: phone,
        profileId:
          user.consultantProfileId ??
          user.ConsultantProfileId ??
          profile?.profileId ??
          profile?.ProfileId ??
          user.profileId ??
          user.ProfileId ??
          0,
        consultantIsOnline:
          user.consultantIsOnline ??
          user.ConsultantIsOnline ??
          profile?.consultantIsOnline ??
          null,
        consultantIsAvailable:
          user.consultantIsAvailable ??
          user.ConsultantIsAvailable ??
          null,
        lastSeenAt: user.lastSeenAt ?? user.LastSeenAt ?? null,
        attendanceResponse: profile?.attendanceResponse,
        scoreLogResponse: profile?.scoreLogResponse,
        leadsAssignmentItemsResponse: profile?.leadsAssignmentItemsResponse,
      };
    });
  }

  getConsultantProfile(profileId: number): Observable<AdminConsultantProfile> {
    return this.http
      .get<unknown>(`${this.apiBaseUrl}/admin/consultants/${profileId}`, {
        headers: this.authHeaders(),
      })
      .pipe(
        map((response) => this.normalizeConsultantProfile(response)),
        catchError((error) =>
          throwError(() =>
            this.toUserFacingError(error, "دریافت پروفایل مشاور انجام نشد"),
          ),
        ),
      );
  }

  updateConsultantLimit(
    profileId: number,
    limitNumber: number | null,
  ): Observable<ApiCommandResponse<ConsultantLimitUpdate>> {
    return this.http
      .patch<ApiCommandResponse<ConsultantLimitUpdate>>(
        `${this.apiBaseUrl}/admin/consultants/${profileId}/limit`,
        { limitNumber, LimitNumber: limitNumber },
        { headers: this.authHeaders() },
      )
      .pipe(
        map((response) => this.normalizeLimitUpdateResponse(response)),
        this.ensureCommandSucceeded("ذخیره محدودیت دریافت شماره انجام نشد"),
      );
  }

  private normalizeLimitUpdateResponse(
    response: ApiCommandResponse<ConsultantLimitUpdate>,
  ): ApiCommandResponse<ConsultantLimitUpdate> {
    const normalized = this.normalizeCommandResponse(
      response,
      "ذخیره محدودیت دریافت شماره انجام نشد",
    );
    const source = this.unwrapResponseData(normalized);
    const record = this.isRecord(source) ? source : {};

    return {
      ...normalized,
      data: {
        limitNumber: this.readNumber(record, "limitNumber", "LimitNumber"),
        effectiveDailyLimit:
          this.readNumber(record, "effectiveDailyLimit", "EffectiveDailyLimit") ??
          10,
        todayPickupCount:
          this.readNumber(record, "todayPickupCount", "TodayPickupCount") ?? 0,
      },
    };
  }

  private normalizeConsultantProfile(response: unknown): AdminConsultantProfile {
    const source = this.unwrapResponseData(response);
    const record = this.isRecord(source) ? source : {};

    return {
      profileId:
        this.readNumber(record, "profileId", "ProfileId") ?? 0,
      userId: String(this.readValue(record, "userId", "UserId") ?? ""),
      firstName: String(this.readValue(record, "firstName", "FirstName") ?? ""),
      lastName: String(this.readValue(record, "lastName", "LastName") ?? ""),
      phoneNumber: String(
        this.readValue(record, "phoneNumber", "PhoneNumber") ?? "",
      ),
      userIsActive:
        this.readBoolean(record, "userIsActive", "UserIsActive") ?? false,
      userIsCompleteProfile:
        this.readBoolean(
          record,
          "userIsCompleteProfile",
          "UserIsCompleteProfile",
        ) ?? false,
      nationalCode: String(
        this.readValue(record, "nationalCode", "NationalCode") ?? "",
      ),
      address: String(this.readValue(record, "address", "Address") ?? ""),
      isAvailable:
        this.readBoolean(record, "isAvailable", "IsAvailable") ?? false,
      isOnline: this.readBoolean(record, "isOnline", "IsOnline") ?? false,
      isCompleteProfile:
        this.readBoolean(record, "isCompleteProfile", "IsCompleteProfile") ??
        false,
      workStartTime: this.readString(
        record,
        "workStartTime",
        "WorkStartTime",
      ),
      workEndTime: this.readString(record, "workEndTime", "WorkEndTime"),
      notes: this.readString(record, "notes", "Notes"),
      lastOnlineAt: this.readString(record, "lastOnlineAt", "LastOnlineAt"),
      lastOfflineAt: this.readString(record, "lastOfflineAt", "LastOfflineAt"),
      limitNumber: this.readNumber(record, "limitNumber", "LimitNumber"),
      effectiveDailyLimit:
        this.readNumber(record, "effectiveDailyLimit", "EffectiveDailyLimit") ??
        10,
      todayPickupCount:
        this.readNumber(record, "todayPickupCount", "TodayPickupCount") ?? 0,
    };
  }

  getAttendance(
    consultantProfileId: number,
    pageNumber = 1,
    pageSize = 10,
  ): Observable<PaginatedResponse<AttendanceItem>> {
    return this.http
      .get<unknown>(`${this.apiBaseUrl}/Attendance`, {
        headers: this.authHeaders(),
        params: this.toParams({ consultantProfileId, pageNumber, pageSize }),
      })
      .pipe(
        map((response) =>
          this.normalizePaginatedResponse<AttendanceItem>(response, {
            pageNumber,
            pageSize,
          }),
        ),
      );
  }

  exportUsersReport(): Observable<Blob> {
    return this.exportCsvReport("users/export");
  }

  exportLeadsReport(): Observable<Blob> {
    return this.exportCsvReport("leads/export");
  }

  exportConsultantsReport(): Observable<Blob> {
    return this.exportCsvReport("consultants/export");
  }

  getConsultantsDailySummary(): Observable<ConsultantsDailySummaryResponse> {
    return this.http
      .get<unknown>(`${this.apiBaseUrl}/admin/reports/consultants/daily-summary`, {
        headers: this.authHeaders(),
      })
      .pipe(
        map((response) => this.normalizeConsultantsDailySummary(response)),
        catchError((error) =>
          throwError(() =>
            this.toUserFacingError(error, "دریافت گزارش روزانه مشاوران انجام نشد"),
          ),
        ),
      );
  }

  exportLeadCallReports(
    filters: LeadCallReportExportFilters,
  ): Observable<Blob> {
    return this.exportCsvReport("lead-call-reports/export", filters);
  }

  getLeadsReport(filters: LeadsReportFilters): Observable<LeadsReportResponse> {
    return this.http.get<LeadsReportResponse>(
      `${this.apiBaseUrl}/admin/reports/leads`,
      { headers: this.authHeaders(), params: this.toParams(filters) },
    ).pipe(
      catchError((error) => throwError(() =>
        this.toUserFacingError(error, "دریافت گزارش لیدها انجام نشد"),
      )),
    );
  }

  exportFilteredLeadsReport(filters: LeadsReportFilters): Observable<Blob> {
    const { pageNumber: _pageNumber, pageSize: _pageSize, ...exportFilters } = filters;
    return this.exportCsvReport("leads/export", exportFilters);
  }

  getDailyReservationsReport(
    filters: DailyReservationsReportFilters,
  ): Observable<DailyReservationsReport> {
    return this.http
      .get<DailyReservationsReport>(
        `${this.apiBaseUrl}/admin/reports/daily-reservations`,
        { headers: this.authHeaders(), params: this.toParams(filters) },
      )
      .pipe(
        catchError((error) =>
          throwError(() =>
            this.toUserFacingError(error, "دریافت گزارش روزانه رزروها انجام نشد"),
          ),
        ),
      );
  }

  exportDailyReservationsReport(
    filters: DailyReservationsReportFilters,
  ): Observable<Blob> {
    return this.exportCsvReport("daily-reservations/export", filters);
  }

  getPatientFinanceReport(
    filters: PatientFinanceReportFilters,
  ): Observable<PatientFinanceReportResponse> {
    return this.http.get<PatientFinanceReportResponse>(
      `${this.apiBaseUrl}/admin/reports/patient-finances`,
      { headers: this.authHeaders(), params: this.toParams(filters) },
    ).pipe(catchError((error) => throwError(() =>
      this.toUserFacingError(error, "دریافت گزارش حسابداری بیماران انجام نشد"),
    )));
  }

  exportPatientFinanceReport(filters: PatientFinanceReportFilters): Observable<Blob> {
    const { page: _page, pageSize: _pageSize, ...exportFilters } = filters;
    return this.http.get(
      `${this.apiBaseUrl}/admin/reports/patient-finances/export`,
      {
        headers: this.authHeaders().set(
          "Accept",
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        ),
        params: this.toParams(exportFilters),
        responseType: "blob",
      },
    ).pipe(catchError((error) => throwError(() =>
      this.toUserFacingError(error, "دریافت خروجی اکسل حسابداری انجام نشد"),
    )));
  }

  getPatientFinanceFile(fileNumber: string): Observable<AdminPatientFinanceFile | null> {
    return this.http.get<AdminPatientFinanceFile>(
      `${this.apiBaseUrl}/admin/reports/patient-finances/files/${fileNumber}`,
      {
        headers: this.authHeaders(),
      },
    ).pipe(
      map(response => response ?? null),
      catchError(error => throwError(() =>
        this.toUserFacingError(error, "دریافت صورت‌حساب‌های بیمار انجام نشد"),
      )),
    );
  }

  uploadGuaranteeDocument(caseId: string, file: File): Observable<ApiCommandResponse<{ id: string; guaranteeDocument: string | null }>> {
    const body = new FormData();
    body.append("file", file);
    return this.http.post<ApiCommandResponse<{ id: string; guaranteeDocument: string | null }>>(
      `${this.apiBaseUrl}/secretary/patient-financial-cases/${caseId}/guarantee-document`,
      body,
      { headers: this.authHeaders() },
    );
  }

  deleteGuaranteeDocument(caseId: string): Observable<ApiCommandResponse<{ id: string; guaranteeDocument: string | null }>> {
    return this.http.delete<ApiCommandResponse<{ id: string; guaranteeDocument: string | null }>>(
      `${this.apiBaseUrl}/secretary/patient-financial-cases/${caseId}/guarantee-document`,
      { headers: this.authHeaders() },
    );
  }

  updatePatientFinance(caseId: string, request: UpdatePatientFinanceRequest): Observable<ApiCommandResponse> {
    return this.http.put<ApiCommandResponse>(
      `${this.apiBaseUrl}/admin/reports/patient-finances/${caseId}`,
      request,
      { headers: this.authHeaders() },
    ).pipe(catchError((error) => throwError(() =>
      this.toUserFacingError(error, "ویرایش حسابداری بیمار انجام نشد"),
    )));
  }

  deletePatientFinance(caseId: string): Observable<ApiCommandResponse> {
    return this.http.delete<ApiCommandResponse>(
      `${this.apiBaseUrl}/admin/reports/patient-finances/${caseId}`,
      { headers: this.authHeaders() },
    ).pipe(catchError((error) => throwError(() =>
      this.toUserFacingError(error, "حذف حسابداری بیمار انجام نشد"),
    )));
  }

  getPatientFinanceDetails(caseId: string): Observable<ApiCommandResponse<AdminPatientFinanceDetails>> {
    return this.http.get<ApiCommandResponse<AdminPatientFinanceDetails>>(
      `${this.apiBaseUrl}/admin/reports/patient-finances/${caseId}/details`,
      { headers: this.authHeaders() },
    );
  }

  updatePatientCheque(id: number, request: UpdateAdminChequeRequest): Observable<ApiCommandResponse> {
    return this.http.put<ApiCommandResponse>(`${this.apiBaseUrl}/admin/reports/patient-finances/cheques/${id}`, request, { headers: this.authHeaders() });
  }

  deletePatientCheque(id: number): Observable<ApiCommandResponse> {
    return this.http.delete<ApiCommandResponse>(`${this.apiBaseUrl}/admin/reports/patient-finances/cheques/${id}`, { headers: this.authHeaders() });
  }

  updatePatientPromissoryNote(id: number, request: UpdateAdminPromissoryNoteRequest): Observable<ApiCommandResponse> {
    return this.http.put<ApiCommandResponse>(`${this.apiBaseUrl}/admin/reports/patient-finances/promissory-notes/${id}`, request, { headers: this.authHeaders() });
  }

  deletePatientPromissoryNote(id: number): Observable<ApiCommandResponse> {
    return this.http.delete<ApiCommandResponse>(`${this.apiBaseUrl}/admin/reports/patient-finances/promissory-notes/${id}`, { headers: this.authHeaders() });
  }

  exportReservationsReport(
    filters: { from?: string; to?: string; consultantProfileId?: number } = {},
  ): Observable<Blob> {
    return this.exportCsvReport("reservations/export", filters);
  }

  exportConsultantAttendanceConfirmationsReport(
    filters: { from?: string; to?: string; consultantProfileId?: number } = {},
  ): Observable<Blob> {
    return this.exportCsvReport(
      "consultant-attendance-confirmations/export",
      filters,
    );
  }

  getConsultantAttendanceConfirmations(
    filters: SecretaryReservationFilters,
  ): Observable<PaginatedResponse<SecretaryReservation>> {
    return this.getSecretaryReservations({
      ...filters,
      onlyConsultantAttendanceConfirmed: true,
    });
  }

  private exportCsvReport(
    path: string,
    params?: object,
  ): Observable<Blob> {
    let headers = this.authHeaders();
    if (headers.has("Authorization")) {
      headers = headers.set("Accept", "text/csv");
    }

    return this.http
      .get(`${this.apiBaseUrl}/admin/reports/${path}`, {
        headers,
        ...(params ? { params: this.toParams(params) } : {}),
        responseType: "blob",
      })
      .pipe(
        switchMap((blob) => from(ensureCsvBlob(blob))),
        catchError((error) =>
          throwError(() =>
            this.toUserFacingError(error, "دریافت گزارش انجام نشد"),
          ),
        ),
      );
  }

  getConsultantLeads(
    filters: LeadFilters,
  ): Observable<PaginatedResponse<LeadAssignmentItem>> {
    return this.http
      .get<unknown>(`${this.apiBaseUrl}/Consultant/GetLeads`, {
        headers: this.authHeaders(),
        params: this.toParams(filters),
      })
      .pipe(
        map((response) =>
          this.normalizePaginatedResponse<LeadAssignmentItem>(
            response,
            filters,
          ),
        ),
      );
  }

  getSecretaryReservations(
    filters: SecretaryReservationFilters,
  ): Observable<PaginatedResponse<SecretaryReservation>> {
    return this.http
      .get<unknown>(`${this.apiBaseUrl}/Reservation/SecretaryReservations`, {
        headers: this.authHeaders(),
        params: this.toParams(filters),
      })
      .pipe(
        map((response) =>
          this.normalizePaginatedResponse<SecretaryReservation>(
            response,
            filters,
          ),
        ),
      );
  }

  getReservationAttendanceReviews(
    pageNumber = 1,
    pageSize = 20,
  ): Observable<PaginatedResponse<SecretaryReservation>> {
    return this.getSecretaryReservations({
      onlyWaitingForSecretaryReview: true,
      pageNumber,
      pageSize,
    });
  }

  completePatientProfile(
    payload: CompletePatientProfileRequest,
  ): Observable<ApiCommandResponse<CompletePatientProfileResponse>> {
    return this.http
      .post<ApiCommandResponse<CompletePatientProfileResponse>>(
        `${this.apiBaseUrl}/Reservation/CompletePatientProfile`,
        payload,
        {
          headers: this.authHeaders(),
        },
      )
      .pipe(this.ensureCommandSucceeded("تشکیل پرونده بیمار انجام نشد"));
  }

  reviewAttendance(
    payload: ReviewAttendanceRequest,
  ): Observable<ApiCommandResponse> {
    return this.http
      .post<ApiCommandResponse>(
        `${this.apiBaseUrl}/Reservation/ReviewAttendance`,
        payload,
        {
          headers: this.authHeaders(),
        },
      )
      .pipe(this.ensureCommandSucceeded("ثبت بررسی حضور انجام نشد"));
  }

  getSystemLeads(
    filters: LeadFilters,
  ): Observable<PaginatedResponse<LeadAssignmentItem>> {
    return this.http
      .get<unknown>(`${this.apiBaseUrl}/LeadAssignment`, {
        headers: this.authHeaders(),
        params: this.toParams(filters),
      })
      .pipe(
        map((response) =>
          this.normalizePaginatedResponse<LeadAssignmentItem>(
            response,
            filters,
          ),
        ),
      );
  }

  private unwrap<T>(response: unknown): T {
    const wrapper = response as { data?: T; result?: T };
    return wrapper?.data ?? wrapper?.result ?? response as T;
  }

  private authHeaders(): HttpHeaders {
    const token = this.auth.authToken();
    return token
      ? new HttpHeaders({ Authorization: `Bearer ${token}` })
      : new HttpHeaders();
  }

  private toParams(source: object): HttpParams {
    let params = new HttpParams();

    Object.entries(source as Record<string, unknown>).forEach(
      ([key, value]) => {
        if (value === null || value === undefined || value === "") return;
        params = params.set(key, String(value));
      },
    );

    return params;
  }

  private ensureCommandSucceeded<T>(fallback: string) {
    return (source: Observable<ApiCommandResponse<T>>) =>
      source.pipe(
        map((response) => this.normalizeCommandResponse(response, fallback)),
        catchError((error) =>
          throwError(() => this.toUserFacingError(error, fallback)),
        ),
      );
  }

  private normalizePaginatedResponse<T>(
    response: unknown,
    filters: { pageNumber: number; pageSize: number },
  ): PaginatedResponse<T> {
    const source = this.unwrapResponseData(response);
    const items = this.readItems<T>(source);
    const totalCount =
      this.readNumber(source, "totalCount", "total", "count", "recordsTotal") ??
      this.readNumber(
        response,
        "totalCount",
        "total",
        "count",
        "recordsTotal",
      ) ??
      items.length;
    const pageSize =
      this.readNumber(source, "pageSize", "take", "limit") ??
      this.readNumber(response, "pageSize", "take", "limit") ??
      filters.pageSize;
    const pageNumber =
      this.readNumber(source, "pageNumber", "page", "currentPage") ??
      this.readNumber(response, "pageNumber", "page", "currentPage") ??
      filters.pageNumber;
    const totalPages =
      this.readNumber(source, "totalPages", "pages", "pageCount") ??
      this.readNumber(response, "totalPages", "pages", "pageCount") ??
      Math.ceil(totalCount / Math.max(1, pageSize));

    return this.finalizePaginatedResponse(
      {
        items,
        totalCount,
        pageNumber,
        pageSize,
        totalPages,
        raw: response,
        source,
      },
      filters,
    );
  }

  private finalizePaginatedResponse<T>(
    payload: {
      items: T[];
      totalCount: number;
      pageNumber: number | null;
      pageSize: number | null;
      totalPages: number | null;
      raw?: unknown;
      source?: unknown;
    },
    filters: { pageNumber: number; pageSize: number },
  ): PaginatedResponse<T> {
    const totalCount = Math.max(0, payload.totalCount);
    const pageSize =
      payload.pageSize && payload.pageSize > 0
        ? payload.pageSize
        : filters.pageSize;
    const pageNumber =
      payload.pageNumber && payload.pageNumber > 0
        ? payload.pageNumber
        : filters.pageNumber;
    const maxReasonablePages = Math.max(
      1,
      Math.ceil(totalCount / Math.max(1, pageSize)),
    );
    let totalPages =
      payload.totalPages ?? maxReasonablePages;

    if (
      !Number.isFinite(totalPages) ||
      totalPages >= 2_147_483_647 ||
      totalPages <= 0 ||
      totalPages > maxReasonablePages
    ) {
      totalPages = maxReasonablePages;
    }

    return {
      items: payload.items,
      totalCount,
      pageNumber,
      pageSize,
      totalPages: Math.max(1, totalPages),
      raw: payload.raw,
      source: payload.source,
    };
  }

  private unwrapResponseData(response: unknown): unknown {
    if (Array.isArray(response)) return response;
    if (!this.isRecord(response)) return response;

    const payload = this.readValue(
      response,
      "data",
      "result",
      "value",
      "payload",
    );
    if (payload !== null && payload !== undefined) {
      return payload;
    }

    return response;
  }

  private readItems<T>(source: unknown): T[] {
    if (Array.isArray(source)) return source as T[];
    if (!this.isRecord(source)) return [];

    for (const key of [
      "items",
      "data",
      "result",
      "values",
      "records",
      "list",
    ]) {
      const value = this.readValue(source, key);
      if (Array.isArray(value)) return value as T[];
      const nestedItems = this.readItems<T>(value);
      if (nestedItems.length) return nestedItems;
    }

    const firstArray = Object.values(source).find(Array.isArray);
    return Array.isArray(firstArray) ? (firstArray as T[]) : [];
  }

  private readNumber(source: unknown, ...keys: string[]): number | null {
    if (!this.isRecord(source)) return null;

    for (const key of keys) {
      const value = this.readValue(source, key);
      if (value === null || value === undefined || value === "") continue;
      const numeric = typeof value === "number" ? value : Number(value);
      if (Number.isFinite(numeric)) return numeric;
    }

    return null;
  }

  private normalizeConsultantsDailySummary(
    response: unknown,
  ): ConsultantsDailySummaryResponse {
    const source = this.unwrapResponseData(response);
    const items = this.readItems<Record<string, unknown>>(source).map((item) => ({
      consultantProfileId:
        this.readNumber(item, "consultantProfileId", "ConsultantProfileId") ?? 0,
      firstName: String(this.readValue(item, "firstName", "FirstName") ?? ""),
      lastName: String(this.readValue(item, "lastName", "LastName") ?? ""),
      phoneNumber: String(this.readValue(item, "phoneNumber", "PhoneNumber") ?? ""),
      todayReservationsCount:
        this.readNumber(item, "todayReservationsCount", "TodayReservationsCount") ??
        0,
    }));

    return {
      date: this.readString(source, "date", "Date") ?? "",
      items,
    };
  }

  private normalizeCommandResponse<T>(
    response: ApiCommandResponse<T>,
    fallback: string,
  ): ApiCommandResponse<T> {
    const success = this.readBoolean(
      response,
      "isSuccess",
      "success",
      "succeeded",
    );
    const message =
      this.readString(response, "message", "error") ?? response.message ?? "";

    if (success === false) {
      throw new Error(message || fallback);
    }

    return {
      ...response,
      isSuccess: success ?? true,
      message,
      data: this.readValue(response, "data", "result", "value") as
        | T
        | undefined,
    };
  }

  private readBoolean(source: unknown, ...keys: string[]): boolean | null {
    if (!this.isRecord(source)) return null;

    for (const key of keys) {
      const value = this.readValue(source, key);
      if (typeof value === "boolean") return value;
      if (typeof value === "string") {
        const normalized = value.trim().toLowerCase();
        if (["true", "1", "yes"].includes(normalized)) return true;
        if (["false", "0", "no"].includes(normalized)) return false;
      }
    }

    return null;
  }

  private readString(source: unknown, ...keys: string[]): string | null {
    if (!this.isRecord(source)) return null;

    for (const key of keys) {
      const value = this.readValue(source, key);
      if (typeof value === "string" && value.trim()) return value;
    }

    return null;
  }

  private readValue(source: unknown, ...keys: string[]): unknown {
    if (!this.isRecord(source)) return undefined;

    for (const key of keys) {
      if (Object.prototype.hasOwnProperty.call(source, key)) return source[key];
    }

    const entries = Object.entries(source);
    for (const key of keys) {
      const match = entries.find(
        ([entryKey]) => entryKey.toLowerCase() === key.toLowerCase(),
      );
      if (match) return match[1];
    }

    return undefined;
  }

  private isRecord(value: unknown): value is Record<string, unknown> {
    return typeof value === "object" && value !== null;
  }

  private toUserFacingError(error: unknown, fallback: string): Error {
    if (error instanceof Error && error.message) return error;
    if (typeof error === "object" && error !== null && "error" in error) {
      const httpError = error as {
        error?: { message?: string } | string;
        message?: string;
      };
      if (typeof httpError.error === "object" && httpError.error?.message)
        return new Error(httpError.error.message);
      if (typeof httpError.error === "string" && httpError.error)
        return new Error(httpError.error);
      if (httpError.message) return new Error(httpError.message);
    }

    return new Error(fallback);
  }
}
