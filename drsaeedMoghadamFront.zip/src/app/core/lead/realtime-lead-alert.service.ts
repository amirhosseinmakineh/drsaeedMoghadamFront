import { Injectable, OnDestroy } from "@angular/core";
import { Router } from "@angular/router";
import { Subject, catchError, firstValueFrom, of } from "rxjs";
import { AuthService } from "../auth/auth.service";
import {
  BroadcastRealtimeLeadItem,
  ConsultantDashboardService,
} from "../consultant/consultant-dashboard.service";
import { NotificationService } from "../push/notification.service";
import {
  startRealtimeLeadAlertSoundLoop,
  stopRealtimeLeadAlertSoundLoop,
} from "../push/lead-alert-sound";
import { REALTIME_LEAD_VIBRATE_PATTERN } from "../push/lead-alert.constants";
import { ToastService } from "../toast/toast.service";
import {
  RealtimeLeadNotificationDetails,
  normalizeLeadField,
  resolveRealtimeLeadNotificationBody,
  resolveRealtimeLeadNotificationTitle,
} from "./lead-alert-copy";
import { RealtimeLeadPickupService } from "./realtime-lead-pickup.service";

export interface RealtimeLeadAlert {
  leadId: number;
  leadLimitType: "Realtime" | "Burnt";
  userName?: string | null;
  phoneNumber?: string | null;
  isSubmitting: boolean;
  receivedAt: Date;
}

type ServiceWorkerMessage =
  | { type: "RealtimeLead"; leadId: number; title?: string; body?: string }
  | { type: "RealtimeLeadTaken"; leadId: number }
  | { type: "RealtimeLeadPickup"; leadId: number }
  | { type: "RealtimeLeadOpen"; leadId: number };

interface IncomingLeadDetails extends RealtimeLeadNotificationDetails {
  leadLimitType?: "Realtime" | "Burnt";
  title?: string;
  body?: string;
}

const DISMISSED_LEAD_COOLDOWN_MS = 10_000;
const REMINDER_INTERVAL_MS = 6_000;

@Injectable({ providedIn: "root" })
export class RealtimeLeadAlertService implements OnDestroy {
  private readonly alertsSubject = new Subject<readonly RealtimeLeadAlert[]>();
  private readonly activeAlerts = new Map<number, RealtimeLeadAlert>();
  private readonly handledLeadIds = new Set<number>();
  private readonly dismissedLeadCooldownTimers = new Map<
    number,
    ReturnType<typeof setTimeout>
  >();
  private readonly processingLeadIds = new Set<number>();
  private readonly awaitingPickupLeadIds = new Set<number>();
  private initialized = false;
  private pollTimer: ReturnType<typeof setInterval> | null = null;
  private pollingProfileId: number | null = null;
  private pollingInFlight = false;
  private readonly onServiceWorkerMessage = (
    event: MessageEvent<ServiceWorkerMessage>,
  ): void => {
    void this.handleServiceWorkerMessage(event.data);
  };
  private readonly onPushMessage = (event: Event): void => {
    const detail = (
      event as CustomEvent<{
        title?: string;
        body?: string;
        data?: Record<string, string>;
      }>
    ).detail;
    const leadId = Number(detail?.data?.["leadId"]);
    if (
      detail?.data?.["type"] !== "RealtimeLead" ||
      !Number.isFinite(leadId) ||
      leadId <= 0
    ) {
      if (detail?.data?.["type"] === "RealtimeLead") {
        console.error("Invalid leadId in push payload", detail);
      }
      return;
    }

    const leadLimitType =
      detail.data?.["leadLimitType"] === "Burnt" ? "Burnt" : "Realtime";

    void this.notifyIncomingLead(leadId, {
      leadLimitType,
      userName: detail?.data?.["userName"] ?? detail?.data?.["UserName"],
      phoneNumber:
        detail?.data?.["phoneNumber"] ?? detail?.data?.["PhoneNumber"],
      isReminder: detail?.data?.["isReminder"] === "true",
      title: detail?.title,
      body: detail?.body,
    });
  };

  readonly alerts$ = this.alertsSubject.asObservable();

  constructor(
    private readonly auth: AuthService,
    private readonly consultantApi: ConsultantDashboardService,
    private readonly pickupService: RealtimeLeadPickupService,
    private readonly notifications: NotificationService,
    private readonly toast: ToastService,
    private readonly router: Router,
  ) {}

  initialize(): void {
    if (this.initialized || typeof window === "undefined") return;

    this.initialized = true;
    navigator.serviceWorker?.addEventListener(
      "message",
      this.onServiceWorkerMessage,
    );
    window.addEventListener("consultant-push-message", this.onPushMessage);
  }

  ngOnDestroy(): void {
    this.stopPolling();
    for (const leadId of this.awaitingPickupLeadIds) {
      stopRealtimeLeadAlertSoundLoop(leadId);
    }
    this.awaitingPickupLeadIds.clear();
    for (const timer of this.dismissedLeadCooldownTimers.values()) {
      clearTimeout(timer);
    }
    this.dismissedLeadCooldownTimers.clear();
    navigator.serviceWorker?.removeEventListener(
      "message",
      this.onServiceWorkerMessage,
    );
    window.removeEventListener("consultant-push-message", this.onPushMessage);
    this.alertsSubject.complete();
  }

  startPolling(profileId: number): void {
    this.pollingProfileId = profileId;
    if (this.pollTimer) return;

    void this.pollBroadcastLeads();
    this.pollTimer = setInterval(() => {
      void this.pollBroadcastLeads();
    }, 5000);
  }

  stopPolling(): void {
    if (this.pollTimer) {
      clearInterval(this.pollTimer);
      this.pollTimer = null;
    }
    this.pollingProfileId = null;
    this.stopAwaitingPickupSounds();
    for (const leadId of [...this.activeAlerts.keys()]) {
      this.dismissLead(leadId);
    }
  }

  async tryPickupLead(leadId: number): Promise<void> {
    const profileId = this.getProfileId();
    if (!profileId) {
      this.toast.error("شناسه پروفایل مشاور پیدا نشد.");
      return;
    }

    const alert = this.activeAlerts.get(leadId);
    if (alert?.isSubmitting) return;

    if (alert) {
      alert.isSubmitting = true;
      this.emitAlerts();
    }

    // Do not repeat the CanPickupLead preflight here. Alerts are already checked
    // before they are displayed and the atomic pickup endpoint enforces the same
    // limit. A second, serial request made the primary action noticeably slower.
    const result = await firstValueFrom(
      this.pickupService.pickupLead(leadId, profileId),
    );

    if (result.status === "success") {
      this.toast.success(result.message);
      this.markLeadTaken(leadId);
      this.notifyLeadPickedUp(leadId, result.callDeadlineAt);
      // Updating availability is housekeeping and must not hold up showing the
      // newly assigned lead. Reconcile it in the background instead.
      void this.setConsultantOfflineAfterPickup(profileId);
      await this.router.navigate(["/dashboard/consultant"], {
        queryParams: {
          section: "leads",
          type: "realtime",
          leadAssignmentId: leadId,
        },
      });
      return;
    }

    if (result.status === "dailyLimitReached") {
      this.showDailyLimitNotificationOnce(result.message);
      this.markLeadTaken(leadId);
      return;
    }

    if (result.status === "alreadyTaken") {
      this.toast.info(result.message || "این لید قبلاً برداشته شده است.");
      this.markLeadTaken(leadId);
      return;
    }

    if (result.status === "workloadBlocked") {
      this.toast.error(result.message || "ابتدا شماره‌های قبلی را تعیین تکلیف کنید.");
      this.markLeadTaken(leadId);
      window.dispatchEvent(
        new CustomEvent("consultant-workload-blocked", {
          detail: { message: result.message },
        }),
      );
      return;
    }

    this.toast.error(result.message || "برداشتن لید ناموفق بود.");
    if (alert) {
      alert.isSubmitting = false;
      this.emitAlerts();
    }
  }

  dismissLead(leadId: number): void {
    this.activeAlerts.delete(leadId);
    this.suppressLeadTemporarily(leadId);
    void this.notifications.closeRealtimeLeadNotification(leadId);
    this.emitAlerts();
  }

  private markLeadTaken(leadId: number): void {
    this.awaitingPickupLeadIds.delete(leadId);
    stopRealtimeLeadAlertSoundLoop(leadId);
    this.dismissLead(leadId);
  }

  private stopAwaitingPickupSounds(): void {
    for (const leadId of [...this.awaitingPickupLeadIds]) {
      stopRealtimeLeadAlertSoundLoop(leadId);
    }
    this.awaitingPickupLeadIds.clear();
  }

  private async pollBroadcastLeads(): Promise<void> {
    if (this.pollingInFlight) return;
    const profileId = this.pollingProfileId;
    if (!profileId || this.auth.user()?.role !== "consultant") return;

    this.pollingInFlight = true;
    try {
      const response = await firstValueFrom(
        this.consultantApi.getBroadcastRealtimeLeads(profileId),
      );
      if (!response.canReceive) {
        this.stopAwaitingPickupSounds();
        return;
      }

      const leads = response.leads ?? [];
      const broadcastLeadIds = new Set(
        leads
          .map((item) => this.readBroadcastLeadId(item))
          .filter((leadId): leadId is number => leadId !== null),
      );
      const now = Date.now();

      for (const leadId of [...this.awaitingPickupLeadIds]) {
        if (!broadcastLeadIds.has(leadId)) {
          this.markLeadTaken(leadId);
        }
      }

      for (const [leadId, alert] of this.activeAlerts) {
        if (now - alert.receivedAt.getTime() < REMINDER_INTERVAL_MS) continue;
        if (this.handledLeadIds.has(leadId)) continue;
        if (!leads.some((item) => this.readBroadcastLeadId(item) === leadId)) {
          continue;
        }

        await this.notifyIncomingLead(leadId, {
          leadLimitType: alert.leadLimitType,
          userName: alert.userName,
          phoneNumber: alert.phoneNumber,
          isReminder: true,
        });
      }

      const lead = leads.find((item) => {
        const itemLeadId = this.readBroadcastLeadId(item);
        return (
          itemLeadId &&
          !this.handledLeadIds.has(itemLeadId) &&
          !this.activeAlerts.has(itemLeadId) &&
          !this.processingLeadIds.has(itemLeadId)
        );
      });
      if (!lead) return;

      const leadId = this.readBroadcastLeadId(lead);
      if (!leadId) return;

      await this.notifyIncomingLead(leadId, {
        leadLimitType: this.readBroadcastLeadLimitType(lead),
        userName: lead.userName ?? lead.UserName,
        phoneNumber: lead.phoneNumber ?? lead.PhoneNumber,
      });
    } catch (error) {
      console.warn("[RealtimeLead] Fallback polling failed", error);
    } finally {
      this.pollingInFlight = false;
    }
  }

  private readBroadcastLeadId(lead: BroadcastRealtimeLeadItem): number | null {
    const leadId = Number(lead.leadAssignmentId ?? lead.LeadAssignmentId ?? 0);
    return Number.isFinite(leadId) && leadId > 0 ? leadId : null;
  }

  private readBroadcastLeadLimitType(
    lead: BroadcastRealtimeLeadItem,
  ): "Realtime" | "Burnt" {
    return (lead.leadLimitType ?? lead.LeadLimitType) === "Burnt"
      ? "Burnt"
      : "Realtime";
  }

  private async handleServiceWorkerMessage(
    message: ServiceWorkerMessage | undefined,
  ): Promise<void> {
    if (!message?.type) return;

    if (this.auth.user()?.role !== "consultant") return;

    switch (message.type) {
      case "RealtimeLeadTaken":
        this.markLeadTaken(message.leadId);
        break;
      case "RealtimeLeadPickup":
        await this.tryPickupLead(message.leadId);
        break;
      case "RealtimeLeadOpen":
        await this.router.navigate(["/dashboard/consultant"], {
          queryParams: {
            section: "leads",
            type: "realtime",
            leadAssignmentId: message.leadId,
          },
        });
        break;
      default:
        break;
    }
  }

  private async notifyIncomingLead(
    leadId: number,
    details: IncomingLeadDetails = {},
  ): Promise<void> {
    if (!leadId || this.handledLeadIds.has(leadId) || this.processingLeadIds.has(leadId)) {
      return;
    }

    this.processingLeadIds.add(leadId);
    try {
      const profileId = this.getProfileId();
      if (!profileId) return;

      const canPickup = await firstValueFrom(
        this.pickupService.canPickupLead(profileId),
      );
      if (!canPickup) {
        this.showDailyLimitNotificationOnce();
        void this.notifications.closeRealtimeLeadNotification(leadId);
        return;
      }

      const enrichedDetails = await this.enrichIncomingLeadDetails(
        leadId,
        details,
        profileId,
      );
      const notificationDetails: RealtimeLeadNotificationDetails = {
        leadLimitType: enrichedDetails.leadLimitType,
        userName: enrichedDetails.userName,
        phoneNumber: enrichedDetails.phoneNumber,
        isReminder: enrichedDetails.isReminder,
      };
      const title = resolveRealtimeLeadNotificationTitle(
        notificationDetails,
        enrichedDetails.title,
      );
      const body = resolveRealtimeLeadNotificationBody(
        notificationDetails,
        enrichedDetails.body,
      );

      const existingAlert = this.activeAlerts.get(leadId);
      if (existingAlert) {
        existingAlert.leadLimitType = enrichedDetails.leadLimitType ?? "Realtime";
        existingAlert.userName =
          notificationDetails.userName ?? existingAlert.userName;
        existingAlert.phoneNumber =
          notificationDetails.phoneNumber ?? existingAlert.phoneNumber;
        existingAlert.receivedAt = new Date();
      } else {
        this.activeAlerts.set(leadId, {
          leadId,
          leadLimitType: enrichedDetails.leadLimitType ?? "Realtime",
          userName: notificationDetails.userName,
          phoneNumber: notificationDetails.phoneNumber,
          isSubmitting: false,
          receivedAt: new Date(),
        });
      }

      this.awaitingPickupLeadIds.add(leadId);
      startRealtimeLeadAlertSoundLoop(leadId);
      this.emitAlerts();

      if (this.isAppInForeground()) {
        void this.notifications.closeRealtimeLeadNotification(leadId);
        return;
      }

      await this.notifications.showLocalNotification(title, body, {
        tag: `realtime-lead-${leadId}`,
        requireInteraction: true,
        vibrate: [...REALTIME_LEAD_VIBRATE_PATTERN],
        data: {
          type: "RealtimeLead",
          leadId: String(leadId),
          leadLimitType: enrichedDetails.leadLimitType ?? "Realtime",
          userName: notificationDetails.userName ?? "",
          phoneNumber: notificationDetails.phoneNumber ?? "",
          isReminder: notificationDetails.isReminder ? "true" : "false",
        },
      });
    } finally {
      this.processingLeadIds.delete(leadId);
    }
  }

  private async enrichIncomingLeadDetails(
    leadId: number,
    details: IncomingLeadDetails,
    profileId: number,
  ): Promise<IncomingLeadDetails> {
    const userName = normalizeLeadField(details.userName);
    const phoneNumber = normalizeLeadField(details.phoneNumber);
    if (userName && phoneNumber) return details;

    try {
      const response = await firstValueFrom(
        this.consultantApi.getBroadcastRealtimeLeads(profileId),
      );
      const lead = (response.leads ?? []).find(
        (item) => this.readBroadcastLeadId(item) === leadId,
      );
      if (!lead) return details;

      return {
        ...details,
        leadLimitType: this.readBroadcastLeadLimitType(lead),
        userName:
          userName ||
          normalizeLeadField(lead.userName ?? lead.UserName) ||
          details.userName,
        phoneNumber:
          phoneNumber ||
          normalizeLeadField(lead.phoneNumber ?? lead.PhoneNumber) ||
          details.phoneNumber,
      };
    } catch {
      return details;
    }
  }

  private async setConsultantOfflineAfterPickup(profileId: number): Promise<void> {
    this.stopPolling();

    try {
      await firstValueFrom(
        this.consultantApi
          .setOnlineStatus({
            profileId,
            isOnline: false,
            isOffline: true,
          })
          .pipe(catchError(() => of(null))),
      );
    } catch {
      // Ignore transient offline API errors; dashboard refresh will reconcile status.
    }
  }

  private notifyLeadPickedUp(
    leadId: number,
    callDeadlineAt?: string | null,
  ): void {
    if (typeof window === "undefined") return;
    window.dispatchEvent(
      new CustomEvent("consultant-lead-picked-up", {
        detail: { leadId, callDeadlineAt },
      }),
    );
  }

  private showDailyLimitNotificationOnce(message?: string): void {
    const todayKey = new Date().toISOString().slice(0, 10);
    if (this.limitNotifiedDates.has(todayKey)) return;

    this.limitNotifiedDates.add(todayKey);
    this.toast.info(
      message ??
        "سقف دریافت لید امروز تکمیل شده است.",
    );
  }

  private suppressLeadTemporarily(leadId: number): void {
    this.handledLeadIds.add(leadId);

    const existingTimer = this.dismissedLeadCooldownTimers.get(leadId);
    if (existingTimer) clearTimeout(existingTimer);

    this.dismissedLeadCooldownTimers.set(
      leadId,
      setTimeout(() => {
        this.handledLeadIds.delete(leadId);
        this.dismissedLeadCooldownTimers.delete(leadId);
      }, DISMISSED_LEAD_COOLDOWN_MS),
    );
  }

  private isAppInForeground(): boolean {
    if (typeof document === "undefined") return false;

    return (
      document.visibilityState === "visible" &&
      (typeof document.hasFocus !== "function" || document.hasFocus())
    );
  }

  private emitAlerts(): void {
    this.alertsSubject.next([...this.activeAlerts.values()]);
  }

  private getProfileId(): number {
    const user = this.auth.user();
    const profileId = user?.consultantProfileId ?? user?.profileId ?? 0;
    return Number.isFinite(profileId) && profileId > 0 ? profileId : 0;
  }

  private readonly limitNotifiedDates = new Set<string>();
}
