/** Mirrors `DentalDashboard.Domain.Enums.LeadAssignmentType`. */
export const LeadAssignmentType = {
  RealTime: 1,
  ConsultantPatient: 3,
} as const;

/** Mirrors `DentalDashboard.Domain.Models.LeadAssignmentState`. */
export const LeadAssignmentState = {
  New: 1,
  Assigned: 2,
  Contacted: 3,
  Pending: 4,
  Converted: 5,
  Expired: 6,
  Rejected: 7,
  NoAnswer: 8,
  ClosedByConsultant: 9,
} as const;

/** Mirrors `AdminReportPersianLabels.ToPersian(LeadAssignmentState)`. */
export const LEAD_ASSIGNMENT_STATE_LABELS: Record<number, string> = {
  [LeadAssignmentState.New]: "جدید",
  [LeadAssignmentState.Assigned]: "تخصیص‌یافته",
  [LeadAssignmentState.Contacted]: "تماس گرفته شده",
  [LeadAssignmentState.Pending]: "پیگیری",
  [LeadAssignmentState.Converted]: "تبدیل شده",
  [LeadAssignmentState.Expired]: "منقضی شده",
  [LeadAssignmentState.Rejected]: "رد شده",
  [LeadAssignmentState.NoAnswer]: "پاسخ نداد",
  [LeadAssignmentState.ClosedByConsultant]: "بسته‌شده توسط مشاور",
};

/** Mirrors `AdminReportPersianLabels.ToPersian(LeadAssignmentType)`. */
export const LEAD_ASSIGNMENT_TYPE_LABELS: Record<number, string> = {
  [LeadAssignmentType.RealTime]: "آنی",
  [LeadAssignmentType.ConsultantPatient]: "بیمار مشاور",
};

export const CONSULTANT_WORK_START_HOUR = 9;
export const CONSULTANT_WORK_END_HOUR = 21;

const LEAD_ASSIGNMENT_TYPE_BY_NAME: Record<string, number> = {
  realtime: LeadAssignmentType.RealTime,
  consultantpatient: LeadAssignmentType.ConsultantPatient,
};

const LEAD_ASSIGNMENT_STATE_BY_NAME: Record<string, number> = {
  new: LeadAssignmentState.New,
  assigned: LeadAssignmentState.Assigned,
  contacted: LeadAssignmentState.Contacted,
  pending: LeadAssignmentState.Pending,
  converted: LeadAssignmentState.Converted,
  expired: LeadAssignmentState.Expired,
  rejected: LeadAssignmentState.Rejected,
  noanswer: LeadAssignmentState.NoAnswer,
  closedbyconsultant: LeadAssignmentState.ClosedByConsultant,
};

export function resolveLeadAssignmentType(value: unknown): number | null {
  return resolveEnumValue(value, LEAD_ASSIGNMENT_TYPE_BY_NAME);
}

export function resolveLeadAssignmentState(value: unknown): number | null {
  return resolveEnumValue(value, LEAD_ASSIGNMENT_STATE_BY_NAME);
}

export function leadAssignmentTypeLabel(value: number | null): string {
  return value === null ? "نامشخص" : (LEAD_ASSIGNMENT_TYPE_LABELS[value] ?? "نامشخص");
}

export function leadAssignmentStateLabel(value: number | null): string {
  return value === null ? "نامشخص" : (LEAD_ASSIGNMENT_STATE_LABELS[value] ?? "نامشخص");
}

export function isConsultantWorkingHours(date: Date = new Date()): boolean {
  const hour = date.getHours();
  return hour >= CONSULTANT_WORK_START_HOUR && hour < CONSULTANT_WORK_END_HOUR;
}

export function isConsultantOnlineBlockedByTime(date: Date = new Date()): boolean {
  return date.getHours() >= CONSULTANT_WORK_END_HOUR;
}

export function canConsultantGoOnline(date: Date = new Date()): boolean {
  return !isConsultantOnlineBlockedByTime(date);
}

export const ADMIN_LEAD_STATE_FILTER_OPTIONS: ReadonlyArray<{
  value: number | null;
  label: string;
}> = [
  { value: null, label: "همه وضعیت‌ها" },
  { value: LeadAssignmentState.New, label: LEAD_ASSIGNMENT_STATE_LABELS[LeadAssignmentState.New] },
  { value: LeadAssignmentState.Assigned, label: LEAD_ASSIGNMENT_STATE_LABELS[LeadAssignmentState.Assigned] },
  { value: LeadAssignmentState.Contacted, label: LEAD_ASSIGNMENT_STATE_LABELS[LeadAssignmentState.Contacted] },
  { value: LeadAssignmentState.Pending, label: LEAD_ASSIGNMENT_STATE_LABELS[LeadAssignmentState.Pending] },
  { value: LeadAssignmentState.Converted, label: LEAD_ASSIGNMENT_STATE_LABELS[LeadAssignmentState.Converted] },
  { value: LeadAssignmentState.Expired, label: LEAD_ASSIGNMENT_STATE_LABELS[LeadAssignmentState.Expired] },
  { value: LeadAssignmentState.Rejected, label: LEAD_ASSIGNMENT_STATE_LABELS[LeadAssignmentState.Rejected] },
  { value: LeadAssignmentState.NoAnswer, label: LEAD_ASSIGNMENT_STATE_LABELS[LeadAssignmentState.NoAnswer] },
  { value: LeadAssignmentState.ClosedByConsultant, label: LEAD_ASSIGNMENT_STATE_LABELS[LeadAssignmentState.ClosedByConsultant] },
];

export const ADMIN_LEAD_TYPE_FILTER_OPTIONS: ReadonlyArray<{
  value: number | null;
  label: string;
}> = [
  { value: null, label: "همه نوع‌ها" },
  { value: LeadAssignmentType.RealTime, label: LEAD_ASSIGNMENT_TYPE_LABELS[LeadAssignmentType.RealTime] },
  { value: LeadAssignmentType.ConsultantPatient, label: LEAD_ASSIGNMENT_TYPE_LABELS[LeadAssignmentType.ConsultantPatient] },
];

function resolveEnumValue(
  value: unknown,
  byName: Record<string, number>,
): number | null {
  if (value === null || value === undefined || value === "") return null;

  if (typeof value === "number" && Number.isFinite(value)) return value;

  if (typeof value === "string") {
    const trimmed = value.trim();
    const named = byName[trimmed.toLowerCase()];
    if (named !== undefined) return named;

    const numeric = Number(trimmed);
    if (Number.isFinite(numeric)) return numeric;
  }

  return null;
}
