import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable, computed, signal } from "@angular/core";
import { Observable, catchError, map, throwError } from "rxjs";
import { environment } from "../../../environments/environment";

export type AuthRole = "admin" | "consultant" | "secretary" | "patient";

export interface AuthUser {
  firstName: string;
  lastName: string;
  role: AuthRole;
  roles: AuthRole[];
  roleName: string;
  token: string;
  userId?: string;
  phoneNumber?: string;
  profileId?: number;
  consultantProfileId?: number;
  isCompleteProfile?: boolean;
  secretaryType?: string;
  allowedDays?: string[];
  secretaryPermissions?: string[];
}

export interface RegisterRequest {
  firstName: string;
  lastName: string;
  phoneNumber: string;
  passwordHash: string;
  isCompleteProfile: boolean;
  avatarImageName: string | null;
  gender: number;
  birthDate?: string;
  roleName?: string;
  reservationId?: number;
  nationalCode?: string;
  address?: string;
  emergencyPhoneNumber?: string | null;
  insuranceName?: string | null;
  notes?: string | null;
}

interface ApiResponse<T> {
  isSuccess: boolean;
  message: string;
  data: T;
}

type LoginPayload = {
  phoneNumber: string;
  passwordHash: string;
};

type TokenResponseData =
  | string
  | {
      token?: string;
      accessToken?: string;
      access_token?: string;
      jwt?: string;
      userId?: string;
      role?: string;
      roles?: string[];
      Roles?: string[];
      firstName?: string;
      lastName?: string;
      profileId?: number | string;
      consultantProfileId?: number | string;
      isCompleteProfile?: boolean | string;
      secretaryType?: string;
      SecretaryType?: string;
      allowedDays?: string[] | string;
      AllowedDays?: string[] | string;
      permissions?: string[] | string;
      Permissions?: string[] | string;
    };

interface StoredSession {
  token: string;
  user: Omit<AuthUser, "token">;
}

@Injectable({ providedIn: "root" })
export class AuthService {
  private readonly apiBaseUrl = environment.apiBaseUrl;
  private readonly sessionStorageKey = "clinic-auth-session";
  private readonly dashboardRolePriority: AuthRole[] = [
    "admin",
    "consultant",
    "secretary",
    "patient",
  ];
  private readonly currentUser = signal<AuthUser | null>(this.readSession());

  readonly user = this.currentUser.asReadonly();
  readonly isAuthenticated = computed(() => {
    const user = this.currentUser();
    return user !== null && !this.isTokenExpired(user.token);
  });

  constructor(private http: HttpClient) {}

  register(
    payload: RegisterRequest,
  ): Observable<ApiResponse<{ userId: string; role: string } | null>> {
    return this.http
      .post<
        ApiResponse<{ userId: string; role: string } | null>
      >(`${this.apiBaseUrl}/Auth`, payload)
      .pipe(
        map((response) => {
          if (!response.isSuccess) {
            throw new Error(response.message || "ثبت نام انجام نشد");
          }

          return response;
        }),
        catchError((error) =>
          throwError(() => this.toUserFacingError(error, "خطا در ثبت نام")),
        ),
      );
  }

  registerPushToken(
    deviceToken: string,
  ): Observable<ApiResponse<null>> {
    return this.http
      .post<ApiResponse<null>>(
        `${this.apiBaseUrl}/Auth/RegisterPushToken`,
        { deviceToken },
        { headers: this.authHeaders() },
      )
      .pipe(
        map((response) => {
          if (!response.isSuccess) {
            throw new Error(response.message || "ثبت توکن نوتیفیکیشن انجام نشد");
          }

          return response;
        }),
        catchError((error) =>
          throwError(() =>
            this.toUserFacingError(error, "ثبت توکن نوتیفیکیشن انجام نشد"),
          ),
        ),
      );
  }

  forgotPassword(
    phoneNumber: string,
    newPassword: string,
  ): Observable<ApiResponse<{ userId: string } | null>> {
    const payload = { phoneNumber, newPasswordHash: newPassword };

    return this.http
      .post<
        ApiResponse<{ userId: string } | null>
      >(`${this.apiBaseUrl}/Auth/ForgotPassword`, payload)
      .pipe(
        map((response) => {
          if (!response.isSuccess) {
            throw new Error(response.message || "تغییر رمز عبور انجام نشد");
          }

          return response;
        }),
        catchError((error) =>
          throwError(() =>
            this.toUserFacingError(error, "خطا در تغییر رمز عبور"),
          ),
        ),
      );
  }

  login(phoneNumber: string, password: string): Observable<AuthUser> {
    const payload: LoginPayload = { phoneNumber, passwordHash: password };

    return this.http
      .post<
        ApiResponse<TokenResponseData | null>
      >(`${this.apiBaseUrl}/Auth/Login`, payload)
      .pipe(
        map((response) => {
          if (!response.isSuccess) {
            throw new Error(response.message || "ورود انجام نشد");
          }

          const token = this.extractToken(response);
          if (!token) {
            throw new Error("توکن ورود از سمت سرور دریافت نشد");
          }

          const decodedUser = this.userFromToken(token, response.data);
          const apiRoles = this.extractRolesFromResponseData(response.data).map(
            (role) => this.normalizeRole(role),
          );
          if (apiRoles.length) {
            const sortedRoles = this.sortDashboardRoles(apiRoles);
            decodedUser.roles = sortedRoles;
            decodedUser.role = sortedRoles[0];
            decodedUser.roleName = this.roleNameFromAuthRole(sortedRoles[0]);
          }
          this.saveSession(decodedUser);
          return decodedUser;
        }),
        catchError((error) =>
          throwError(() => this.toUserFacingError(error, "خطا در ورود")),
        ),
      );
  }

  logout(): void {
    const token = this.authToken();
    if (token) {
      this.http
        .post<ApiResponse<unknown>>(
          `${environment.apiBaseUrl}/Auth/Logout`,
          {},
          {
            headers: new HttpHeaders({ Authorization: `Bearer ${token}` }),
          },
        )
        .subscribe({ error: () => undefined });
    }

    this.clearSession();
  }

  invalidateSession(): void {
    this.clearSession();
  }

  updateConsultantProfile(profileId: number, isCompleteProfile = true): void {
    const user = this.currentUser();
    if (!user) return;

    this.saveSession({
      ...user,
      profileId,
      consultantProfileId: profileId,
      isCompleteProfile,
    });
  }

  updateSecretaryProfile(isCompleteProfile = true): void {
    const user = this.currentUser();
    if (!user) return;

    this.saveSession({
      ...user,
      isCompleteProfile,
    });
  }

  isRoleProfileComplete(
    user: AuthUser | null = this.currentUser(),
    role?: AuthRole,
  ): boolean {
    if (!user) return false;

    const checkRole = role ?? user.role;

    if (checkRole === "consultant") {
      const profileId = user.consultantProfileId ?? user.profileId;
      return Boolean(profileId) && user.isCompleteProfile === true;
    }

    if (checkRole === "secretary") {
      return Boolean(user.userId) && user.isCompleteProfile === true;
    }

    return true;
  }

  hasRole(role: AuthRole, user: AuthUser | null = this.currentUser()): boolean {
    return user?.roles?.includes(role) ?? false;
  }

  selectableDashboardRoles(
    user: AuthUser | null = this.currentUser(),
  ): AuthRole[] {
    if (!user?.roles?.length) return [];

    const uniqueRoles = [
      ...new Set(
        user.roles.filter((role) => this.dashboardRolePriority.includes(role)),
      ),
    ];

    return uniqueRoles.sort(
      (left, right) =>
        this.dashboardRolePriority.indexOf(left) -
        this.dashboardRolePriority.indexOf(right),
    );
  }

  needsRoleSelection(user: AuthUser | null = this.currentUser()): boolean {
    return this.selectableDashboardRoles(user).length > 1;
  }

  setActiveRole(role: AuthRole): void {
    const user = this.currentUser();
    if (!user || !this.hasRole(role, user)) return;

    this.saveSession({
      ...user,
      role,
      roleName: this.roleNameFromAuthRole(role),
    });
  }

  dashboardUrl(
    user: AuthUser | null = this.currentUser(),
    role?: AuthRole,
  ): string {
    if (!user) return "/";

    const activeRole = role ?? user.role;
    const base = `/dashboard/${activeRole}`;
    if (!this.isRoleProfileComplete(user, activeRole) && activeRole === "consultant") {
      return `${base}?section=profile`;
    }

    return base;
  }

  roleSelectionUrl(): string {
    return "/select-dashboard";
  }

  authToken(): string | null {
    const currentToken = this.currentUser()?.token;
    if (currentToken?.trim()) {
      if (this.isTokenExpired(currentToken)) {
        this.clearSession();
        return null;
      }
      return currentToken;
    }

    const storedToken = this.readStoredToken();
    if (storedToken && this.isTokenExpired(storedToken)) {
      this.clearSession();
      return null;
    }
    return storedToken;
  }

  roleLabel(role: AuthRole, language: "fa" | "en"): string {
    const labels: Record<AuthRole, { fa: string; en: string }> = {
      admin: { fa: "ادمین", en: "Admin" },
      consultant: { fa: "مشاور", en: "Consultant" },
      secretary: { fa: "منشی", en: "Secretary" },
      patient: { fa: "بیمار", en: "Patient" },
    };

    return labels[role][language];
  }

  private extractToken(
    response: ApiResponse<TokenResponseData | null>,
  ): string | null {
    const root = response as ApiResponse<TokenResponseData | null> & {
      token?: string;
      accessToken?: string;
      access_token?: string;
      jwt?: string;
    };

    if (typeof response.data === "string") return response.data;
    if (response.data?.accessToken) return response.data.accessToken;
    if (response.data?.token) return response.data.token;
    if (response.data?.access_token) return response.data.access_token;
    if (response.data?.jwt) return response.data.jwt;
    return (
      root.accessToken ?? root.token ?? root.access_token ?? root.jwt ?? null
    );
  }

  private userFromToken(
    token: string,
    responseData: TokenResponseData | null,
  ): AuthUser {
    const claims = this.decodeJwtPayload(token);
    const data =
      typeof responseData === "object" && responseData !== null
        ? responseData
        : {};
    const roleName =
      this.claimValue(claims, [
        "role",
        "Role",
        "roles",
        "http://schemas.microsoft.com/ws/2008/06/identity/claims/role",
      ]) ??
      data.role ??
      "Patient";
    const roles = this.extractAllRoles(claims, data);

    return {
      token,
      firstName:
        this.claimValue(claims, [
          "firstName",
          "FirstName",
          "given_name",
          "name",
        ]) ??
        data.firstName ??
        "",
      lastName:
        this.claimValue(claims, [
          "lastName",
          "LastName",
          "family_name",
          "surname",
        ]) ??
        data.lastName ??
        "",
      phoneNumber: this.claimValue(claims, [
        "phoneNumber",
        "PhoneNumber",
        "phone_number",
        "phone",
      ]),
      userId:
        this.claimValue(claims, [
          "userId",
          "UserId",
          "sub",
          "nameid",
          "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier",
        ]) ?? this.dataString(data, "userId", "UserId"),
      profileId:
        this.claimNumber(claims, [
          "profileId",
          "ProfileId",
          "consultantProfileId",
          "ConsultantProfileId",
        ]) ??
        this.dataNumber(
          data,
          "profileId",
          "ProfileId",
          "consultantProfileId",
          "ConsultantProfileId",
        ),
      consultantProfileId:
        this.claimNumber(claims, [
          "consultantProfileId",
          "ConsultantProfileId",
          "profileId",
          "ProfileId",
        ]) ??
        this.dataNumber(
          data,
          "consultantProfileId",
          "ConsultantProfileId",
          "profileId",
          "ProfileId",
        ),
      isCompleteProfile:
        this.claimBoolean(claims, [
          "isCompleteProfile",
          "IsCompleteProfile",
          "profileComplete",
          "ProfileComplete",
        ]) ?? this.dataBoolean(data, "isCompleteProfile"),
      secretaryType:
        this.claimValue(claims, ["secretaryType", "SecretaryType"]) ??
        this.dataString(data, "secretaryType", "SecretaryType"),
      allowedDays: this.stringList(
        claims["allowedDays"] ??
          claims["AllowedDays"] ??
          data["allowedDays"] ??
          data["AllowedDays"],
      ),
      secretaryPermissions: this.stringList(
        claims["permissions"] ??
          claims["Permissions"] ??
          data["permissions"] ??
          data["Permissions"],
      ),
      roleName,
      role: roles[0] ?? this.normalizeRole(roleName),
      roles,
    };
  }

  private extractAllRoles(
    claims: Record<string, unknown>,
    data: Record<string, unknown>,
  ): AuthRole[] {
    const rawRoles = [
      ...this.claimValues(claims, [
        "role",
        "Role",
        "roles",
        "http://schemas.microsoft.com/ws/2008/06/identity/claims/role",
        "http://schemas.microsoft.com/ws/2008/06/identity/claims/role",
      ]),
      ...this.extractRolesFromResponseData(data),
    ];

    const normalized = rawRoles
      .map((role) => this.normalizeRole(role))
      .filter((role, index, roles) => roles.indexOf(role) === index);

    return this.sortDashboardRoles(normalized);
  }

  private extractRolesFromResponseData(
    responseData: TokenResponseData | Record<string, unknown> | null,
  ): string[] {
    if (!responseData || typeof responseData !== "object") return [];

    const data = responseData as Record<string, unknown>;
    const roles = data["roles"] ?? data["Roles"];
    if (!Array.isArray(roles)) return [];

    return roles
      .filter((role): role is string => typeof role === "string" && !!role.trim())
      .map((role) => role.trim());
  }

  private sortDashboardRoles(roles: AuthRole[]): AuthRole[] {
    if (!roles.length) return ["patient"];

    return [...roles].sort(
      (left, right) =>
        this.dashboardRolePriority.indexOf(left) -
        this.dashboardRolePriority.indexOf(right),
    );
  }

  private roleNameFromAuthRole(role: AuthRole): string {
    const roleNames: Record<AuthRole, string> = {
      admin: "Admin",
      consultant: "Consultant",
      secretary: "Secretary",
      patient: "Patient",
    };

    return roleNames[role];
  }

  private normalizeRole(role: string): AuthRole {
    const normalized = role.trim().toLowerCase();

    if (["admin", "administrator", "ادمین"].includes(normalized))
      return "admin";
    if (["consultant", "advisor", "مشاور"].includes(normalized))
      return "consultant";
    if (["secretary", "منشی"].includes(normalized)) return "secretary";
    if (
      ["patient", "normaluser", "user", "بیمار", "کاربر"].includes(normalized)
    )
      return "patient";
    return "patient";
  }

  private decodeJwtPayload(token: string): Record<string, unknown> {
    try {
      const payload = token.split(".")[1];
      if (!payload) return {};

      const normalized = payload.replace(/-/g, "+").replace(/_/g, "/");
      const padded = normalized.padEnd(
        Math.ceil(normalized.length / 4) * 4,
        "=",
      );
      const decoded = atob(padded);
      const bytes = Uint8Array.from(decoded, (character) =>
        character.charCodeAt(0),
      );
      const json = new TextDecoder().decode(bytes);
      return JSON.parse(json) as Record<string, unknown>;
    } catch {
      return {};
    }
  }

  private claimValue(
    claims: Record<string, unknown>,
    keys: string[],
  ): string | undefined {
    for (const key of keys) {
      const value = claims[key];
      if (typeof value === "string" && value.trim()) return value;
      if (
        Array.isArray(value) &&
        typeof value[0] === "string" &&
        value[0].trim()
      )
        return value[0];
    }

    return undefined;
  }

  private claimValues(
    claims: Record<string, unknown>,
    keys: string[],
  ): string[] {
    const values: string[] = [];

    for (const key of keys) {
      const value = claims[key];
      if (typeof value === "string" && value.trim()) {
        values.push(value.trim());
        continue;
      }

      if (Array.isArray(value)) {
        for (const item of value) {
          if (typeof item === "string" && item.trim()) values.push(item.trim());
        }
      }
    }

    return values;
  }

  private stringList(value: unknown): string[] | undefined {
    const values = Array.isArray(value)
      ? value
      : typeof value === "string"
        ? value.split(",")
        : [];
    const normalized = values
      .filter((item): item is string => typeof item === "string")
      .map((item) => item.trim())
      .filter(Boolean);
    return normalized.length ? normalized : undefined;
  }

  private claimNumber(
    claims: Record<string, unknown>,
    keys: string[],
  ): number | undefined {
    for (const key of keys) {
      const value = claims[key];
      const numeric =
        typeof value === "number"
          ? value
          : typeof value === "string"
            ? Number(value)
            : NaN;
      if (Number.isFinite(numeric) && numeric > 0) return numeric;
    }

    return undefined;
  }

  private claimBoolean(
    claims: Record<string, unknown>,
    keys: string[],
  ): boolean | undefined {
    for (const key of keys) {
      const value = claims[key];
      if (typeof value === "boolean") return value;
      if (typeof value === "string") {
        const normalized = value.trim().toLowerCase();
        if (["true", "1", "yes"].includes(normalized)) return true;
        if (["false", "0", "no"].includes(normalized)) return false;
      }
    }

    return undefined;
  }

  private dataNumber(
    data: Record<string, unknown>,
    ...keys: string[]
  ): number | undefined {
    for (const key of keys) {
      const value = data[key];
      const numeric =
        typeof value === "number"
          ? value
          : typeof value === "string"
            ? Number(value)
            : NaN;
      if (Number.isFinite(numeric) && numeric > 0) return numeric;
    }

    return undefined;
  }

  private dataString(
    data: Record<string, unknown>,
    ...keys: string[]
  ): string | undefined {
    for (const key of keys) {
      const value = data[key];
      if (typeof value === "string" && value.trim()) return value.trim();
    }

    return undefined;
  }

  private dataBoolean(
    data: Record<string, unknown>,
    ...keys: string[]
  ): boolean | undefined {
    for (const key of keys) {
      const value = data[key];
      if (typeof value === "boolean") return value;
      if (typeof value === "string") {
        const normalized = value.trim().toLowerCase();
        if (["true", "1", "yes"].includes(normalized)) return true;
        if (["false", "0", "no"].includes(normalized)) return false;
      }
    }

    return undefined;
  }

  private saveSession(user: AuthUser): void {
    this.currentUser.set(user);

    try {
      const { token, ...sessionUser } = user;
      const session: StoredSession = { token, user: sessionUser };
      localStorage.setItem(this.sessionStorageKey, JSON.stringify(session));
    } catch {
      // The in-memory session remains available until page refresh.
    }
  }

  private readStoredToken(): string | null {
    const storageKeys = [
      "clinic-auth-session",
      "token",
      "accessToken",
      "authToken",
      "jwt",
    ];

    try {
      for (const storage of [localStorage, sessionStorage]) {
        for (const key of storageKeys) {
          const token = this.extractTokenFromStoredValue(storage.getItem(key));
          if (token) return token;
        }
      }
    } catch {
      return null;
    }

    return null;
  }

  private extractTokenFromStoredValue(value: string | null): string | null {
    if (!value) return null;

    const trimmed = value.trim();
    if (!trimmed) return null;
    if (this.looksLikeJwt(trimmed)) return trimmed;

    try {
      return this.findTokenInObject(JSON.parse(trimmed));
    } catch {
      return null;
    }
  }

  private findTokenInObject(value: unknown, depth = 0): string | null {
    if (depth > 4 || value === null || value === undefined) return null;
    if (typeof value === "string")
      return this.looksLikeJwt(value) ? value : null;
    if (typeof value !== "object") return null;

    const record = value as Record<string, unknown>;
    for (const key of ["token", "accessToken", "access_token", "jwt"]) {
      const token = record[key];
      if (typeof token === "string" && token.trim()) return token.trim();
    }

    for (const nested of Object.values(record)) {
      const token = this.findTokenInObject(nested, depth + 1);
      if (token) return token;
    }

    return null;
  }

  private looksLikeJwt(value: string): boolean {
    return /^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(
      value.trim(),
    );
  }

  private isTokenExpired(token: string): boolean {
    const expiration = this.decodeJwtPayload(token)["exp"];
    const expirationSeconds =
      typeof expiration === "number" ? expiration : Number(expiration);

    return Number.isFinite(expirationSeconds) &&
      expirationSeconds * 1000 <= Date.now();
  }

  private clearSession(): void {
    this.currentUser.set(null);
    try {
      localStorage.removeItem(this.sessionStorageKey);
    } catch {
      // The in-memory session is still cleared when storage is unavailable.
    }
  }

  private hasJwtRoleClaim(token: string): boolean {
    const claims = this.decodeJwtPayload(token);
    return Boolean(
      this.claimValue(claims, [
        "role",
        "Role",
        "roles",
        "http://schemas.microsoft.com/ws/2008/06/identity/claims/role",
      ]),
    );
  }

  private readSession(): AuthUser | null {
    try {
      const rawSession = localStorage.getItem(this.sessionStorageKey);
      if (!rawSession) return null;

      const session = JSON.parse(rawSession) as StoredSession;
      if (!session.token || !session.user) return null;
      if (this.isTokenExpired(session.token)) {
        localStorage.removeItem(this.sessionStorageKey);
        return null;
      }

      const tokenUser = this.userFromToken(session.token, null);

      const isCompleteProfile =
        session.user.isCompleteProfile === true ||
        tokenUser.isCompleteProfile === true
          ? true
          : (tokenUser.isCompleteProfile ?? session.user.isCompleteProfile);

      return {
        ...tokenUser,
        ...session.user,
        firstName: tokenUser.firstName || session.user.firstName,
        lastName: tokenUser.lastName || session.user.lastName,
        phoneNumber: tokenUser.phoneNumber || session.user.phoneNumber,
        userId: tokenUser.userId || session.user.userId,
        profileId: tokenUser.profileId ?? session.user.profileId,
        consultantProfileId:
          tokenUser.consultantProfileId ?? session.user.consultantProfileId,
        isCompleteProfile,
        roleName: tokenUser.roleName || session.user.roleName,
        roles: this.sortDashboardRoles(
          [
            ...(tokenUser.roles ?? []),
            ...(session.user.roles ?? []),
            session.user.role ?? tokenUser.role,
          ].filter((role): role is AuthRole => Boolean(role)),
        ),
        role: this.hasJwtRoleClaim(session.token)
          ? tokenUser.role
          : (session.user.role ?? tokenUser.role),
        token: session.token,
      };
    } catch {
      return null;
    }
  }

  private authHeaders(): HttpHeaders {
    const token = this.authToken();
    const headers: Record<string, string> = { Accept: "application/json" };
    if (token) headers["Authorization"] = `Bearer ${token}`;
    return new HttpHeaders(headers);
  }

  private toUserFacingError(error: unknown, fallback: string): Error {
    if (error instanceof Error && error.message) return error;
    if (typeof error === "object" && error !== null && "error" in error) {
      const httpError = error as {
        error?: { message?: string } | string;
        message?: string;
      };
      if (typeof httpError.error === "object" && httpError.error?.message)
        return new Error(httpError.error.message);
      if (typeof httpError.error === "string" && httpError.error)
        return new Error(httpError.error);
      if (httpError.message) return new Error(httpError.message);
    }

    return new Error(fallback);
  }
}
