import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, catchError, map, throwError } from 'rxjs';
import { AuthService } from '../auth/auth.service';

export interface ApiCommandResponse<T = unknown> {
  isSuccess: boolean;
  message: string;
  data?: T;
}

export interface PaginatedResponse<T> {
  items: T[];
  totalCount: number;
  pageNumber: number;
  pageSize: number;
  totalPages: number;
  raw?: unknown;
  source?: unknown;
}

export interface CompleteConsultantProfileRequest {
  profileId: number;
  nationalityCode: string;
  address: string;
  isCompleteProfile: boolean;
}

export interface AvailabilityRequest {
  profileId: number;
  isAvailable: boolean;
}

export interface OnlineRequest {
  profileId: number;
  isOnline: boolean;
  isOffline: boolean;
}

export interface ConsultantLead {
  id?: number;
  Id?: number;
  leadAssignmentId?: number;
  LeadAssignmentId?: number;
  userName?: string | null;
  UserName?: string | null;
  fullName?: string | null;
  FullName?: string | null;
  firstName?: string | null;
  FirstName?: string | null;
  lastName?: string | null;
  LastName?: string | null;
  phoneNumber?: string | null;
  PhoneNumber?: string | null;
  mobile?: string | null;
  Mobile?: string | null;
  userPhoneNumber?: string | null;
  UserPhoneNumber?: string | null;
  leadPhoneNumber?: string | null;
  LeadPhoneNumber?: string | null;
  leadAssignmentState?: number | null;
  LeadAssignmentState?: number | null;
  state?: number | null;
  State?: number | null;
  status?: number | null;
  Status?: number | null;
  leadAssignmentType?: number | null;
  LeadAssignmentType?: number | null;
  type?: number | null;
  Type?: number | null;
  assignmentType?: number | null;
  AssignmentType?: number | null;
  requiresThreeMinuteCall?: boolean | null;
  RequiresThreeMinuteCall?: boolean | null;
  callDeadlineAt?: string | null;
  CallDeadlineAt?: string | null;
  isReportSubmitted?: boolean | null;
  IsReportSubmitted?: boolean | null;
  user?: LeadPerson | null;
  User?: LeadPerson | null;
  lead?: LeadPerson | null;
  Lead?: LeadPerson | null;
}

export interface LeadFilters {
  profileId: number;
  leadAssignmentState?: number | null;
  leadAssignmentType?: number | null;
  pageNumber: number;
  pageSize: number;
}

export interface SubmitLeadCallReportRequest {
  leadAssignmentId: number;
  consultantProfileId: number;
  callResult: number;
  reportDescription: string | null;
}

export interface LeadCallReportResponse {
  leadAssignmentId: number;
  consultantProfileId: number;
  isReportSubmitted: boolean;
  reportSubmittedAt?: string;
  leadAssignmentState: number;
  callResult: number;
  isConsultantOnline: boolean;
}

export interface ExpireLeadNoCallRequest {
  leadAssignmentId: number;
  consultantProfileId: number;
}

export interface ExpireLeadNoCallResponse {
  leadAssignmentId: number;
  consultantProfileId: number;
  leadAssignmentState: number;
  deductedScore: number;
  currentScore: number;
  isConsultantOnline: boolean;
}

export interface CreateReservationRequest {
  leadAssignmentId: number;
  consultantProfileId: number;
  reservationAt: string;
  description: string | null;
}

export interface ConsultantReservation {
  id: number;
  leadAssignmentId: number;
  consultantProfileId: number;
  reservationAt: string;
  patientName: string;
  patientPhoneNumber: string;
  description?: string | null;
  isCanceled?: boolean;
}

export interface ReservationFilters {
  consultantProfileId: number;
  from?: string;
  to?: string;
  includeCanceled?: boolean;
  pageNumber: number;
  pageSize: number;
}

interface LeadPerson {
  userName?: string | null;
  UserName?: string | null;
  fullName?: string | null;
  FullName?: string | null;
  name?: string | null;
  Name?: string | null;
  firstName?: string | null;
  FirstName?: string | null;
  lastName?: string | null;
  LastName?: string | null;
  phoneNumber?: string | null;
  PhoneNumber?: string | null;
  mobile?: string | null;
  Mobile?: string | null;
}

@Injectable({ providedIn: 'root' })
export class ConsultantDashboardService {
  private readonly apiBaseUrl = 'http://localhost:5182';

  constructor(private http: HttpClient, private auth: AuthService) {}

  completeProfile(payload: CompleteConsultantProfileRequest): Observable<ApiCommandResponse<number>> {
    return this.http.post<ApiCommandResponse<number>>(`${this.apiBaseUrl}/api/Consultant`, payload, {
      headers: this.authHeaders()
    }).pipe(this.ensureCommandSucceeded('تکمیل پروفایل مشاور انجام نشد'));
  }

  setAvailability(payload: AvailabilityRequest): Observable<ApiCommandResponse> {
    return this.http.post<ApiCommandResponse>(`${this.apiBaseUrl}/api/Consultant/SetAvalableConsultant`, payload, {
      headers: this.authHeaders()
    }).pipe(this.ensureCommandSucceeded('ثبت حضور انجام نشد'));
  }

  setOnlineStatus(payload: OnlineRequest): Observable<ApiCommandResponse> {
    return this.http.post<ApiCommandResponse>(`${this.apiBaseUrl}/api/Consultant/SetOnlineOfflineConsultant`, payload, {
      headers: this.authHeaders()
    }).pipe(this.ensureCommandSucceeded('تغییر وضعیت آنلاین انجام نشد'));
  }

  getLeads(filters: LeadFilters): Observable<PaginatedResponse<ConsultantLead>> {
    return this.http.get<unknown>(`${this.apiBaseUrl}/api/Consultant/GetLeads`, {
      headers: this.authHeaders(),
      params: this.toParams(filters)
    }).pipe(map(response => this.normalizePaginatedResponse<ConsultantLead>(response, filters)));
  }

  submitLeadCallReport(payload: SubmitLeadCallReportRequest): Observable<ApiCommandResponse<LeadCallReportResponse>> {
    return this.http.post<ApiCommandResponse<LeadCallReportResponse>>(`${this.apiBaseUrl}/api/Consultant/SubmitLeadCallReport`, payload, {
      headers: this.authHeaders()
    }).pipe(this.ensureCommandSucceeded('ثبت گزارش تماس انجام نشد'));
  }

  expireLeadNoCall(payload: ExpireLeadNoCallRequest): Observable<ApiCommandResponse<ExpireLeadNoCallResponse>> {
    return this.http.post<ApiCommandResponse<ExpireLeadNoCallResponse>>(`${this.apiBaseUrl}/api/Consultant/ExpireLeadNoCall`, payload, {
      headers: this.authHeaders()
    }).pipe(this.ensureCommandSucceeded('منقضی کردن لید انجام نشد'));
  }

  createReservation(payload: CreateReservationRequest): Observable<ApiCommandResponse<ConsultantReservation>> {
    return this.http.post<ApiCommandResponse<ConsultantReservation>>(`${this.apiBaseUrl}/api/Reservation`, payload, {
      headers: this.authHeaders()
    }).pipe(this.ensureCommandSucceeded('ثبت رزرو انجام نشد'));
  }

  getReservations(filters: ReservationFilters): Observable<PaginatedResponse<ConsultantReservation>> {
    return this.http.get<unknown>(`${this.apiBaseUrl}/api/Reservation/GetConsultantReservations`, {
      headers: this.authHeaders(),
      params: this.toParams(filters)
    }).pipe(map(response => this.normalizePaginatedResponse<ConsultantReservation>(response, filters)));
  }

  private authHeaders(): HttpHeaders {
    const token = this.auth.user()?.token;
    return token ? new HttpHeaders({ Authorization: `Bearer ${token}` }) : new HttpHeaders();
  }

  private toParams(source: object): HttpParams {
    let params = new HttpParams();

    Object.entries(source as Record<string, unknown>).forEach(([key, value]) => {
      if (value === null || value === undefined || value === '') return;
      params = params.set(key, String(value));
    });

    return params;
  }

  private ensureCommandSucceeded<T>(fallback: string) {
    return (source: Observable<ApiCommandResponse<T>>) => source.pipe(
      map(response => this.normalizeCommandResponse(response, fallback)),
      catchError(error => throwError(() => this.toUserFacingError(error, fallback)))
    );
  }

  private normalizePaginatedResponse<T>(response: unknown, filters: { pageNumber: number; pageSize: number }): PaginatedResponse<T> {
    const source = this.unwrapResponseData(response);
    const items = this.readItems<T>(source);
    const totalCount = this.readNumber(source, 'totalCount', 'total', 'count', 'recordsTotal')
      ?? this.readNumber(response, 'totalCount', 'total', 'count', 'recordsTotal')
      ?? items.length;
    const pageSize = this.readNumber(source, 'pageSize', 'take', 'limit')
      ?? this.readNumber(response, 'pageSize', 'take', 'limit')
      ?? filters.pageSize;
    const pageNumber = this.readNumber(source, 'pageNumber', 'page', 'currentPage')
      ?? this.readNumber(response, 'pageNumber', 'page', 'currentPage')
      ?? filters.pageNumber;
    const totalPages = this.readNumber(source, 'totalPages', 'pages', 'pageCount')
      ?? this.readNumber(response, 'totalPages', 'pages', 'pageCount')
      ?? Math.ceil(totalCount / Math.max(1, pageSize));

    return {
      items,
      totalCount,
      pageNumber,
      pageSize,
      totalPages: Math.max(1, totalPages),
      raw: response,
      source
    };
  }

  private unwrapResponseData(response: unknown): unknown {
    if (Array.isArray(response)) return response;
    if (!this.isRecord(response)) return response;

    const payload = this.readValue(response, 'data', 'result', 'value', 'payload');
    if (payload !== null && payload !== undefined) {
      return payload;
    }

    return response;
  }

  private readItems<T>(source: unknown): T[] {
    if (Array.isArray(source)) return source as T[];
    if (!this.isRecord(source)) return [];

    for (const key of ['items', 'data', 'result', 'values', 'records', 'list']) {
      const value = this.readValue(source, key);
      if (Array.isArray(value)) return value as T[];
      const nestedItems = this.readItems<T>(value);
      if (nestedItems.length) return nestedItems;
    }

    const firstArray = Object.values(source).find(Array.isArray);
    return Array.isArray(firstArray) ? firstArray as T[] : [];
  }

  private readNumber(source: unknown, ...keys: string[]): number | null {
    if (!this.isRecord(source)) return null;

    for (const key of keys) {
      const value = this.readValue(source, key);
      if (value === null || value === undefined || value === '') continue;
      const numeric = typeof value === 'number' ? value : Number(value);
      if (Number.isFinite(numeric)) return numeric;
    }

    return null;
  }

  private normalizeCommandResponse<T>(response: ApiCommandResponse<T>, fallback: string): ApiCommandResponse<T> {
    const success = this.readBoolean(response, 'isSuccess', 'success', 'succeeded');
    const message = this.readString(response, 'message', 'error') ?? response.message ?? '';

    if (success === false) {
      throw new Error(message || fallback);
    }

    return {
      ...response,
      isSuccess: success ?? true,
      message,
      data: this.readValue(response, 'data', 'result', 'value') as T | undefined
    };
  }

  private readBoolean(source: unknown, ...keys: string[]): boolean | null {
    if (!this.isRecord(source)) return null;

    for (const key of keys) {
      const value = this.readValue(source, key);
      if (typeof value === 'boolean') return value;
      if (typeof value === 'string') {
        const normalized = value.trim().toLowerCase();
        if (['true', '1', 'yes'].includes(normalized)) return true;
        if (['false', '0', 'no'].includes(normalized)) return false;
      }
    }

    return null;
  }

  private readString(source: unknown, ...keys: string[]): string | null {
    if (!this.isRecord(source)) return null;

    for (const key of keys) {
      const value = this.readValue(source, key);
      if (typeof value === 'string' && value.trim()) return value;
    }

    return null;
  }

  private readValue(source: unknown, ...keys: string[]): unknown {
    if (!this.isRecord(source)) return undefined;

    for (const key of keys) {
      if (Object.prototype.hasOwnProperty.call(source, key)) return source[key];
    }

    const entries = Object.entries(source);
    for (const key of keys) {
      const match = entries.find(([entryKey]) => entryKey.toLowerCase() === key.toLowerCase());
      if (match) return match[1];
    }

    return undefined;
  }

  private isRecord(value: unknown): value is Record<string, unknown> {
    return typeof value === 'object' && value !== null;
  }

  private toUserFacingError(error: unknown, fallback: string): Error {
    if (error instanceof Error && error.message) return error;
    if (typeof error === 'object' && error !== null && 'error' in error) {
      const httpError = error as { error?: { message?: string } | string; message?: string };
      if (typeof httpError.error === 'object' && httpError.error?.message) return new Error(httpError.error.message);
      if (typeof httpError.error === 'string' && httpError.error) return new Error(httpError.error);
      if (httpError.message) return new Error(httpError.message);
    }

    return new Error(fallback);
  }
}
