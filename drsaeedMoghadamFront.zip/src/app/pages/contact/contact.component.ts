import { Component, signal } from "@angular/core";
import { NgFor, NgIf } from "@angular/common";
import { FormsModule } from "@angular/forms";
import {
  ContactFormModel,
  DENTAL_SERVICES,
  LanguageCode,
  pickText,
} from "../../models/clinic.model";
import { BaseDatepickerComponent } from "../../shared/base/base-datepicker/base-datepicker.component";
import { FaIconComponent } from "../../shared/ui/fa-icon/fa-icon.component";
import { ToastService } from "../../core/toast/toast.service";
import { NG_MODEL_UPDATE_ON_BLUR } from "../../shared/forms/ng-model-options";
import { AnalyticsService } from "../../core/analytics/analytics.service";

@Component({
  selector: "app-contact",
  standalone: true,
  imports: [FormsModule, NgFor, NgIf, BaseDatepickerComponent, FaIconComponent],
  templateUrl: "./contact.component.html",
  styleUrl: "./contact.component.scss",
})
export class ContactComponent {
  language = signal<LanguageCode>("fa");
  sent = signal(false);
  feedback = signal("");
  feedbackType = signal<"success" | "error">("success");
  services = DENTAL_SERVICES;
  form: ContactFormModel = {
    fullName: "",
    phone: "",
    serviceId: DENTAL_SERVICES[0].id,
    message: "",
  };
  protected readonly pickText = pickText;
  readonly ngModelBlurOptions = NG_MODEL_UPDATE_ON_BLUR;
  infoItems = [
    {
      icon: "phone",
      title: { fa: "تماس مشاور", en: "Consultant call" },
      text: {
        fa: "شماره خود را ثبت کنید تا برای راهنمایی اولیه تماس گرفته شود.",
        en: "Leave your number for an initial guidance call.",
      },
    },
    {
      icon: "location",
      title: { fa: "مراجعه حضوری", en: "In-person visit" },
      text: {
        fa: "مسیر مراجعه پس از هماهنگی با کلینیک اعلام می‌شود.",
        en: "Visit directions are shared after clinic coordination.",
      },
    },
    {
      icon: "clock",
      title: { fa: "ساعات پاسخگویی", en: "Response hours" },
      text: {
        fa: "شنبه تا پنجشنبه، ۹ تا ۲۰",
        en: "Saturday to Thursday, 9:00 to 20:00",
      },
    },
  ];

  constructor(
    private toast: ToastService,
    private analytics: AnalyticsService,
  ) {}

  setLanguage(language: LanguageCode): void {
    this.language.set(language);
  }

  submit(): void {
    const validationError = this.validateContactForm();
    if (validationError) {
      this.analytics.track("consultation_form_submit", { service_name: this.form.serviceId, cta_location: "contact_form", result: "failure" });
      this.showFeedback(validationError, "error");
      return;
    }

    this.sent.set(true);
    this.analytics.track("consultation_form_submit", { service_name: this.form.serviceId, cta_location: "contact_form", result: "success" });
    this.showFeedback(
      this.language() === "fa"
        ? "درخواست شما ثبت شد."
        : "Your request has been recorded.",
      "success",
    );
  }

  validateContactForm(): string | null {
    const isFa = this.language() === "fa";
    if (!this.form.fullName.trim())
      return isFa ? "نام و نام خانوادگی الزامی است" : "Full name is required";
    if (this.form.fullName.trim().length > 100)
      return isFa
        ? "نام نباید بیشتر از ۱۰۰ کاراکتر باشد"
        : "Full name must be at most 100 characters";
    if (!/^09\d{9}$/.test(this.form.phone.trim()))
      return isFa ? "شماره موبایل معتبر نیست" : "Mobile number is invalid";
    if (!this.services.some((service) => service.id === this.form.serviceId))
      return isFa ? "درمان مورد نظر معتبر نیست" : "Selected service is invalid";
    if (this.form.message.trim().length > 1000)
      return isFa
        ? "پیام کوتاه نباید بیشتر از ۱۰۰۰ کاراکتر باشد"
        : "Short message must be at most 1000 characters";
    return null;
  }

  private showFeedback(message: string, type: "success" | "error"): void {
    this.feedback.set(message);
    this.feedbackType.set(type);
    if (type === "success") {
      this.toast.success(message);
      return;
    }
    this.toast.error(message);
  }

  openAuth(): void {
    window.dispatchEvent(new CustomEvent("open-auth-dialog"));
  }

}
