import { CommonModule } from "@angular/common";
import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  Output,
  SimpleChanges,
} from "@angular/core";
import { FormsModule } from "@angular/forms";
import { Subscription, finalize } from "rxjs";
import {
  ConsultantDashboardService,
  ConsultantReservation,
  ConfirmAttendanceRequest,
  AttendanceConfirmationStatusFilter,
  UpdateReservationRequest,
} from "../../core/consultant/consultant-dashboard.service";
import {
  attendanceScoreLabel,
  attendanceStatusPresentation,
  canConsultantEditReservation,
  canConsultantConfirmDueReservation,
  isAwaitingConsultantAttendanceConfirmation,
  isPendingConsultantConfirmationNotYetDue,
  isSecretaryReviewCompleted,
  readAttendanceStatus,
} from "../../core/reservation/reservation-attendance";
import { ToastService } from "../../core/toast/toast.service";
import { NG_MODEL_UPDATE_ON_BLUR } from "../../shared/forms/ng-model-options";
import { createCoalescedMarkForCheck } from "../../shared/change-detection/coalesce-mark-for-check";
import { BaseDialogComponent } from "../../shared/base/base-dialog/base-dialog.component";
import { BaseDatepickerComponent } from "../../shared/base/base-datepicker/base-datepicker.component";
import { ReservationSyncService } from "../../core/reservation/reservation-sync.service";
import { DENTAL_SERVICE_OPTIONS, dentalServicesOf, formatDentalServices } from "../../core/reservation/dental-services";
import { reservationPatientCount, validatePatientCount } from "../../core/reservation/reservation.model";
import {
  combineIranDateAndTime,
  formatIranDateTime,
  formatReservationTime,
  nowInIran,
  startOfIranDay,
  toIranDateInputValue,
  toIranTimeInputValue,
} from "../../utils/iran-datetime.util";

export type ConsultantReservationTab = "pending" | "all" | "completed";

@Component({
  selector: "app-consultant-reservations-panel",
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    BaseDialogComponent,
    BaseDatepickerComponent,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: "./consultant-reservations-panel.component.html",
  styleUrl: "./consultant-reservations-panel.component.scss",
})
export class ConsultantReservationsPanelComponent
  implements OnInit, OnChanges, OnDestroy
{
  @Input({ required: true }) profileId = 0;
  @Input() profileReady = false;
  @Output() pendingCountChange = new EventEmitter<number>();

  activeTab: ConsultantReservationTab = "pending";
  items: ConsultantReservation[] = [];
  notes: Record<number, string> = {};
  loading = false;
  savingId: number | null = null;
  feedback = "";
  feedbackType: "success" | "error" = "success";
  pageNumber = 1;
  pageSize = 20;
  totalPages = 1;
  totalCount = 0;
  searchText = "";
  patientNameFilter = "";
  patientPhoneFilter = "";
  patientCityFilter = "";
  attendanceStatusFilter: AttendanceConfirmationStatusFilter | "" = "";
  fromDate: Date | null = null;
  toDate: Date | null = null;
  readonly fromDatePickerLabel = { fa: "از تاریخ مراجعه", en: "Visit date from" };
  readonly toDatePickerLabel = { fa: "تا تاریخ مراجعه", en: "Visit date to" };
  readonly attendanceStatusOptions: ReadonlyArray<{
    value: AttendanceConfirmationStatusFilter;
    label: string;
  }> = [
    { value: "PendingConsultantConfirmation", label: "در انتظار تأیید مشاور" },
    { value: "ConsultantConfirmedPresent", label: "حضور تأییدشده توسط مشاور" },
    { value: "ConsultantConfirmedAbsent", label: "عدم حضور تأییدشده توسط مشاور" },
    { value: "SecretaryApproved", label: "تأیید منشی" },
    { value: "SecretaryRejected", label: "رد منشی" },
  ];
  pendingCount = 0;
  editDialogOpen = false;
  editSaving = false;
  editingReservation: ConsultantReservation | null = null;
  editForm = {
    reservationDate: null as Date | null,
    reservationTime: "",
    patientCount: 1,
    patientCity: "",
    patientRegion: "",
    attendanceProbabilityPercent: 8,
    attendancePrediction: "",
    secondaryPhoneNumber: "",
    description: "",
    dentalServices: [] as number[],
  };
  readonly dentalServiceOptions = DENTAL_SERVICE_OPTIONS;
  readonly dentalServicesLabel = formatDentalServices;
  readonly reservationDatePickerLabel = {
    fa: "تاریخ رزرو",
    en: "Reservation date",
  };

  private loadRequestId = 0;
  private pollId: ReturnType<typeof setInterval> | null = null;
  private loadSubscription: Subscription | null = null;
  private readonly realtimeSubscription: Subscription;
  private searchDebounceId: ReturnType<typeof setTimeout> | null = null;
  private destroyed = false;
  private loadPending = false;
  private initialLoadStarted = false;
  private readonly onVisibilityChange = (): void => {
    if (document.visibilityState === "visible" && this.profileReady) this.load();
  };
  readonly ngModelBlurOptions = NG_MODEL_UPDATE_ON_BLUR;
  private readonly markDirty: () => void;

  constructor(
    private consultantApi: ConsultantDashboardService,
    private toast: ToastService,
    reservationSync: ReservationSyncService,
    private cdr: ChangeDetectorRef,
  ) {
    this.markDirty = createCoalescedMarkForCheck(
      this.cdr,
      () => this.destroyed,
    );
    this.realtimeSubscription = reservationSync.refreshRequested$.subscribe(() => {
      if (this.profileReady) this.load();
    });
  }

  ngOnInit(): void {
    document.addEventListener("visibilitychange", this.onVisibilityChange);
    if (this.profileReady) {
      this.loadInitial();
      this.startPolling();
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes["profileReady"]?.currentValue === true) {
      this.loadInitial();
      this.startPolling();
    }
    if (
      changes["profileId"] &&
      !changes["profileId"].firstChange &&
      this.profileReady
    ) {
      this.load();
    }
  }

  ngOnDestroy(): void {
    this.destroyed = true;
    this.stopPolling();
    this.loadSubscription?.unsubscribe();
    this.realtimeSubscription.unsubscribe();
    if (this.searchDebounceId) clearTimeout(this.searchDebounceId);
    document.removeEventListener("visibilitychange", this.onVisibilityChange);
  }

  setTab(tab: ConsultantReservationTab): void {
    if (this.activeTab === tab) return;
    this.activeTab = tab;
    this.pageNumber = 1;
    this.load();
  }

  load(): void {
    if (!this.profileReady || !this.profileId) return;
    if (this.loading) {
      this.loadPending = true;
      return;
    }

    const requestId = ++this.loadRequestId;
    this.loading = true;
    this.feedback = "";
    this.markDirty();
    this.loadSubscription?.unsubscribe();

    if (this.activeTab === "pending") {
      this.loadSubscription = this.consultantApi
        .getDueConfirmations(this.profileId, {
          fromDate: this.fromDate ? toIranDateInputValue(this.fromDate) : undefined,
          toDate: this.toDate ? toIranDateInputValue(this.toDate) : undefined,
        })
        .pipe(
          finalize(() => {
            if (requestId === this.loadRequestId) {
              this.loading = false;
              this.markDirty();
              this.runPendingLoad();
            }
          }),
        )
        .subscribe({
          next: (items) => {
            if (requestId !== this.loadRequestId) return;
            this.items = items ?? [];
            this.pendingCount = this.items.length;
            this.pendingCountChange.emit(this.pendingCount);
            this.markDirty();
          },
          error: (error) => {
            if (requestId !== this.loadRequestId) return;
            this.items = [];
            this.pendingCount = 0;
            this.pendingCountChange.emit(0);
            this.showFeedback(this.errorMessage(error), "error");
          },
        });
      return;
    }

    this.loadSubscription = this.consultantApi
      .getReservations({
        consultantProfileId: this.profileId,
        fromDate: this.fromDate ? toIranDateInputValue(this.fromDate) : undefined,
        toDate: this.toDate ? toIranDateInputValue(this.toDate) : undefined,
        searchText: this.cleanFilter(this.searchText),
        patientName: this.cleanFilter(this.patientNameFilter),
        patientPhoneNumber: this.cleanFilter(this.patientPhoneFilter),
        patientCity: this.cleanFilter(this.patientCityFilter),
        attendanceConfirmationStatus: this.attendanceStatusFilter || undefined,
        includeCanceled: false,
        onlySecretaryReviewed:
          this.activeTab === "completed" ? true : undefined,
        pageNumber: this.pageNumber,
        pageSize: this.pageSize,
      })
      .pipe(
        finalize(() => {
          if (requestId === this.loadRequestId) {
            this.loading = false;
            this.markDirty();
            this.runPendingLoad();
          }
        }),
      )
      .subscribe({
        next: (response) => {
          if (requestId !== this.loadRequestId) return;
          this.items = response.items ?? [];
          this.pageNumber = response.pageNumber;
          this.totalPages = response.totalPages;
          this.totalCount = response.totalCount;
          this.markDirty();
        },
        error: (error) => {
          if (requestId !== this.loadRequestId) return;
          this.items = [];
          this.showFeedback(this.errorMessage(error), "error");
        },
      });
  }

  goToPage(page: number): void {
    if (page < 1 || page > this.totalPages) return;
    this.pageNumber = page;
    this.load();
  }

  applyFilters(): void {
    if (this.fromDate && this.toDate &&
        toIranDateInputValue(this.fromDate) > toIranDateInputValue(this.toDate)) {
      this.showFeedback("تاریخ شروع نباید بعد از تاریخ پایان باشد", "error");
      return;
    }
    this.pageNumber = 1;
    this.load();
  }

  clearDateFilters(): void {
    this.fromDate = null;
    this.toDate = null;
    this.applyFilters();
  }

  onSearchChange(): void {
    if (this.searchDebounceId) clearTimeout(this.searchDebounceId);
    this.searchDebounceId = setTimeout(() => this.applyFilters(), 400);
  }

  private cleanFilter(value: string): string | undefined {
    return value.trim() || undefined;
  }

  confirm(reservation: ConsultantReservation, patientAttended: boolean): void {
    const reservationId = this.reservationId(reservation);
    if (!this.profileId || !reservationId) return;

    const payload: ConfirmAttendanceRequest = {
      reservationId,
      consultantProfileId: this.profileId,
      patientAttended,
      note: (this.notes[reservationId] || "").trim() || null,
    };

    this.savingId = reservationId;
    this.consultantApi
      .confirmAttendance(payload)
      .pipe(finalize(() => (this.savingId = null)))
      .subscribe({
        next: (response) => {
          this.showFeedback(
            response.message ||
              (patientAttended
                ? "حضور بیمار ثبت شد و برای بررسی منشی ارسال شد"
                : "عدم حضور بیمار ثبت شد و برای بررسی منشی ارسال شد"),
            "success",
          );
          this.load();
        },
        error: (error) => this.showFeedback(this.errorMessage(error), "error"),
      });
  }

  emptyCopy(): string {
    if (this.activeTab === "pending") {
      return "رزروی در انتظار تایید حضور وجود ندارد.";
    }
    if (this.activeTab === "completed") {
      return "رزروی با بررسی نهایی منشی یافت نشد.";
    }
    return "رزروی برای نمایش وجود ندارد.";
  }

  reservationId(reservation: ConsultantReservation): number | null {
    const value =
      reservation.id ??
      reservation.Id ??
      reservation.reservationId ??
      reservation.ReservationId ??
      null;
    const numeric = Number(value);
    return Number.isFinite(numeric) ? numeric : null;
  }

  patientName(reservation: ConsultantReservation): string {
    return reservation.patientName || reservation.PatientName || "بدون نام";
  }

  patientPhone(reservation: ConsultantReservation): string {
    return (
      reservation.patientPhoneNumber || reservation.PatientPhoneNumber || "-"
    );
  }

  patientCity(reservation: ConsultantReservation): string {
    return reservation.patientCity || reservation.PatientCity || "شهر ثبت نشده";
  }

  patientCount(reservation: ConsultantReservation): number {
    return reservation.patientCount ?? reservation.PatientCount ?? 1;
  }

  doctorName(reservation: ConsultantReservation): string {
    return (
      reservation.doctorName?.trim() || reservation.DoctorName?.trim() || "-"
    );
  }

  reservationAt(reservation: ConsultantReservation): string {
    return reservation.reservationAt || reservation.ReservationAt || "";
  }

  reservationAtPersian(reservation: ConsultantReservation): string {
    return (
      reservation.reservationAtPersian?.trim() ||
      reservation.ReservationAtPersian?.trim() ||
      this.formatDateTime(this.reservationAt(reservation))
    );
  }

  probability(reservation: ConsultantReservation): number | string {
    return (
      reservation.attendanceProbabilityPercent ??
      reservation.AttendanceProbabilityPercent ??
      "-"
    );
  }

  attendancePrediction(reservation: ConsultantReservation): string {
    return (
      reservation.attendancePrediction ||
      reservation.AttendancePrediction ||
      "-"
    );
  }

  statusLabel(reservation: ConsultantReservation): string {
    return attendanceStatusPresentation(
      readAttendanceStatus(
        reservation,
        "attendanceConfirmationStatus",
        "AttendanceConfirmationStatus",
      ),
    ).label;
  }

  badgeClass(reservation: ConsultantReservation): string {
    return attendanceStatusPresentation(
      readAttendanceStatus(
        reservation,
        "attendanceConfirmationStatus",
        "AttendanceConfirmationStatus",
      ),
    ).badgeClass;
  }

  canConfirm(reservation: ConsultantReservation): boolean {
    if (this.activeTab === "pending") {
      return isAwaitingConsultantAttendanceConfirmation(reservation);
    }

    return canConsultantConfirmDueReservation(reservation);
  }

  isPendingNotYetDue(reservation: ConsultantReservation): boolean {
    return isPendingConsultantConfirmationNotYetDue(reservation);
  }

  isCompletedTab(reservation: ConsultantReservation): boolean {
    return (
      this.activeTab === "completed" &&
      isSecretaryReviewCompleted(
        readAttendanceStatus(
          reservation,
          "attendanceConfirmationStatus",
          "AttendanceConfirmationStatus",
        ),
      )
    );
  }

  scoreText(reservation: ConsultantReservation): string {
    const applied =
      reservation.isAttendanceScoreApplied ??
      reservation.IsAttendanceScoreApplied;
    const value =
      reservation.attendanceScoreValue ?? reservation.AttendanceScoreValue;
    if (applied && value !== null && value !== undefined) {
      return value > 0 ? `+${value}` : `${value}`;
    }

    return attendanceScoreLabel(
      reservation.secretaryApprovedConsultantConfirmation ??
        reservation.SecretaryApprovedConsultantConfirmation,
    );
  }

  scoreClass(reservation: ConsultantReservation): string {
    const text = this.scoreText(reservation);
    if (text.startsWith("+")) return "success";
    if (text.startsWith("-")) return "danger";
    return "muted";
  }

  formatDateTime(value: string): string {
    return formatIranDateTime(value);
  }

  formatAppointmentTime(value: string): string {
    return formatReservationTime(value);
  }

  canEdit(reservation: ConsultantReservation): boolean {
    return canConsultantEditReservation(reservation);
  }

  openEditDialog(reservation: ConsultantReservation): void {
    if (!this.canEdit(reservation)) return;

    const reservationAt = this.reservationAt(reservation);
    const date = reservationAt ? new Date(reservationAt) : new Date();
    this.editingReservation = reservation;
    this.editForm = {
      reservationDate: Number.isFinite(date.getTime()) ? date : new Date(),
      reservationTime: toIranTimeInputValue(date),
      patientCount: this.patientCount(reservation),
      patientCity:
        this.patientCity(reservation) === "شهر ثبت نشده"
          ? ""
          : this.patientCity(reservation),
      patientRegion:
        reservation.patientRegion || reservation.PatientRegion || "",
      attendanceProbabilityPercent: Number(
        reservation.attendanceProbabilityPercent ??
          reservation.AttendanceProbabilityPercent ??
          8,
      ),
      attendancePrediction:
        reservation.attendancePrediction ||
        reservation.AttendancePrediction ||
        "بیمار گفت در تاریخ و ساعت رزرو شده در مطب حاضر می‌شود.",
      secondaryPhoneNumber:
        reservation.secondaryPhoneNumber ||
        reservation.SecondaryPhoneNumber ||
        "",
      description: reservation.description || reservation.Description || "",
      dentalServices: dentalServicesOf(reservation),
    };
    this.editDialogOpen = true;
    this.markDirty();
  }

  closeEditDialog(): void {
    this.editDialogOpen = false;
    this.editSaving = false;
    this.editingReservation = null;
    this.markDirty();
  }

  setEditReservationDate(date: Date): void {
    this.editForm.reservationDate = date;
  }

  toggleDentalService(service: number, checked: boolean): void {
    const selected = new Set(this.editForm.dentalServices);
    checked ? selected.add(service) : selected.delete(service);
    this.editForm.dentalServices = [...selected];
  }

  submitEdit(): void {
    const reservationId = this.editingReservation
      ? this.reservationId(this.editingReservation)
      : null;
    if (!this.profileId || !reservationId) return;

    if (!this.editForm.reservationDate) {
      this.showFeedback("تاریخ و ساعت رزرو را وارد کنید", "error");
      return;
    }
    if (
      !Number.isInteger(Number(this.editForm.patientCount)) ||
      Number(this.editForm.patientCount) < 1 ||
      Number(this.editForm.patientCount) > 10
    ) {
      this.showFeedback("تعداد بیماران باید بین ۱ تا ۱۰ نفر باشد", "error");
      return;
    }
    if (!this.editForm.dentalServices.length) {
      this.showFeedback("انتخاب حداقل یک خدمت معتبر الزامی است", "error");
      return;
    }

    const reservationAt = combineIranDateAndTime(
      this.editForm.reservationDate,
      this.editForm.reservationTime,
    );
    if (!reservationAt) {
      this.showFeedback("تاریخ و ساعت رزرو را وارد کنید", "error");
      return;
    }

    if (
      !Number.isFinite(this.editForm.attendanceProbabilityPercent) ||
      this.editForm.attendanceProbabilityPercent < 0 ||
      this.editForm.attendanceProbabilityPercent > 100
    ) {
      this.showFeedback("احتمال حضور باید بین ۰ تا ۱۰۰ باشد", "error");
      return;
    }

    const payload: UpdateReservationRequest = {
      reservationAt: reservationAt.toISOString(),
      patientCount: this.editForm.patientCount,
      patientCity: this.editForm.patientCity.trim(),
      patientRegion: this.editForm.patientRegion.trim(),
      attendanceProbabilityPercent: this.editForm.attendanceProbabilityPercent,
      attendancePrediction: this.editForm.attendancePrediction.trim(),
      secondaryPhoneNumber: this.editForm.secondaryPhoneNumber.trim() || null,
      description: this.editForm.description.trim() || null,
      dentalServices: this.editForm.dentalServices,
    };

    this.editSaving = true;
    this.consultantApi
      .updateReservation(reservationId, payload)
      .pipe(finalize(() => (this.editSaving = false)))
      .subscribe({
        next: (response) => {
          this.showFeedback(
            response.message || "زمان رزرو با موفقیت تغییر کرد",
            "success",
          );
          this.closeEditDialog();
          this.load();
        },
        error: (error) => this.showFeedback(this.errorMessage(error), "error"),
      });
  }

  minimumReservationDate(): Date {
    return startOfIranDay(nowInIran());
  }

  private startPolling(): void {
    this.stopPolling();
    this.pollId = setInterval(() => {
      if (
        !this.profileReady ||
        this.loading ||
        this.savingId ||
        this.destroyed ||
        document.visibilityState === "hidden"
      ) {
        return;
      }
      this.load();
    }, 120000);
  }

  private loadInitial(): void {
    if (this.initialLoadStarted) return;
    this.initialLoadStarted = true;
    this.load();
  }

  private runPendingLoad(): void {
    if (!this.loadPending || this.destroyed) return;
    this.loadPending = false;
    queueMicrotask(() => this.load());
  }

  private stopPolling(): void {
    if (this.pollId) {
      clearInterval(this.pollId);
      this.pollId = null;
    }
  }

  private errorMessage(error: unknown): string {
    return error instanceof Error && error.message
      ? error.message
      : "عملیات انجام نشد";
  }

  private showFeedback(message: string, type: "success" | "error"): void {
    this.feedback = message;
    this.feedbackType = type;
    if (type === "success") this.toast.success(message);
    else this.toast.error(message);
    this.markDirty();
  }
}
