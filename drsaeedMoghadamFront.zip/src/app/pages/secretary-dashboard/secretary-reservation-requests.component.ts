import { CommonModule } from "@angular/common";
import {
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChanges,
} from "@angular/core";
import { FormsModule } from "@angular/forms";
import { ActivatedRoute, Router } from "@angular/router";
import { Subscription, finalize, forkJoin } from "rxjs";
import {
  SecretaryDashboardService,
  SecretaryReservation,
  SecretaryAnnouncementStatus,
  ReservationType,
  SecretaryPatientOption,
} from "../../core/secretary/secretary-dashboard.service";
import { ToastService } from "../../core/toast/toast.service";
import {
  AttendanceConfirmationStatus,
  attendanceStatusPresentation,
  readAttendanceStatus,
} from "../../core/reservation/reservation-attendance";
import {
  BaseDatepickerComponent,
  BaseDialogComponent,
} from "../../shared/base";
import { SecretaryDashboardPreset } from "./secretary-overview.component";
import { ReservationSyncService } from "../../core/reservation/reservation-sync.service";
import { AuthService } from "../../core/auth/auth.service";
import {
  formatReservationTime,
  toIranTimeInputValue,
} from "../../utils/iran-datetime.util";
import { DENTAL_SERVICE_OPTIONS, dentalServicesOf, formatDentalServices } from "../../core/reservation/dental-services";
import { reservationPatientCount, validatePatientCount } from "../../core/reservation/reservation.model";

// This workflow status is returned for display/actions and is deliberately not
// used by the attendance filter sent to SecretaryReservations.
enum ReservationRequestStatus {
  PendingSecretaryReview = 1,
  Confirmed = 2,
  Rescheduled = 3,
  Rejected = 4,
  Canceled = 5,
  WaitingPatientConfirmation = 6,
  NeedsFollowUp = 7,
  Attended = 8,
  NoShow = 9,
}

type QuickFilter = "all" | "pending" | "confirmed" | "followup" | "rejected";
type ReservationTypeFilter = "all" | "regular" | "after-sales";
type DialogMode =
  | "details"
  | "confirm"
  | "reschedule"
  | "reject"
  | "contact"
  | "visit";

const SECRETARY_ANNOUNCEMENT_OPTIONS: ReadonlyArray<{
  value: SecretaryAnnouncementStatus;
  label: string;
}> = [
  { value: "NotCalled", label: "تماس نشده" },
  { value: "NoAnswer", label: "پاسخ نداد" },
  { value: "Confirmed", label: "تایید شده" },
  { value: "CancelledByPatient", label: "لغو توسط بیمار" },
  { value: "RescheduleRequested", label: "درخواست تغییر زمان" },
  { value: "CallAgain", label: "تماس مجدد" },
];

const STATUS_OPTIONS = [
  AttendanceConfirmationStatus.PendingConsultantConfirmation,
  AttendanceConfirmationStatus.ConsultantConfirmedPresent,
  AttendanceConfirmationStatus.ConsultantConfirmedAbsent,
  AttendanceConfirmationStatus.SecretaryApproved,
  AttendanceConfirmationStatus.SecretaryRejected,
].map((value) => ({
  value,
  label: attendanceStatusPresentation(value).label,
})) satisfies ReadonlyArray<{
  value: AttendanceConfirmationStatus;
  label: string;
}>;

@Component({
  selector: "app-secretary-reservation-requests",
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    BaseDatepickerComponent,
    BaseDialogComponent,
  ],
  templateUrl: "./secretary-reservation-requests.component.html",
  styleUrl: "./secretary-reservation-requests.component.scss",
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class SecretaryReservationRequestsComponent
  implements OnInit, OnChanges, OnDestroy
{
  @Input() profileReady = false;
  @Input() preset: SecretaryDashboardPreset | null = null;
  @Input() canCreate = false;

  readonly statusOptions = STATUS_OPTIONS;

  readonly secretaryAnnouncementOptions = SECRETARY_ANNOUNCEMENT_OPTIONS;

  items: SecretaryReservation[] = [];
  totalCount = 0;
  pageNumber = 1;
  pageSize = 20;
  totalPages = 1;
  loading = false;
  saving = false;
  errorMessage = "";
  quickFilter: QuickFilter = "all";
  searchText = "";
  consultantName = "";
  statusFilter: AttendanceConfirmationStatus | null = null;
  reservationStatus = "";
  secretaryAnnouncementFilter: SecretaryAnnouncementStatus | null = null;
  reservationDate: Date | null = null;
  fromDate: Date | null = null;
  toDate: Date | null = null;
  dateFilterMode: "exact" | "range" = "exact";
  sortDirection: "asc" | "desc" = "asc";
  reservationTypeFilter: ReservationTypeFilter = "all";

  createDialogOpen = false;
  createLeadAssignmentId: number | null = null;
  createConsultantProfileId: number | null = null;
  createDate: Date | null = null;
  createTime = "";
  createDescription = "";
  createServiceTitle = "";
  createReservationType = ReservationType.AfterSalesService;
  createDentalServices: number[] = [];
  readonly dentalServiceOptions = DENTAL_SERVICE_OPTIONS;
  readonly dentalServicesLabel = formatDentalServices;
  createOptionsLoading = false;
  createOptionsError = "";
  patientSearch = "";
  patientOptions: SecretaryPatientOption[] = [];

  selected: SecretaryReservation | null = null;
  dialogMode: DialogMode | null = null;
  detailsLoading = false;
  detailsError = "";
  note = "";
  reasonCode: number | null = null;
  rejectionText = "";
  newDate: Date | null = null;
  newTime = "";
  editDentalServices: number[] = [];
  editPatientCount = 1;
  contactResult: SecretaryAnnouncementStatus = "NotCalled";
  visitResult = 2;

  private loadSubscription: Subscription | null = null;
  private detailsSubscription: Subscription | null = null;
  private readonly realtimeSubscription: Subscription;
  private requestId = 0;

  constructor(
    private api: SecretaryDashboardService,
    private auth: AuthService,
    private route: ActivatedRoute,
    private router: Router,
    private toast: ToastService,
    private reservationSync: ReservationSyncService,
    private cdr: ChangeDetectorRef,
  ) {
    this.realtimeSubscription = this.reservationSync.refreshRequested$.subscribe(
      () => {
        if (this.profileReady && !this.saving) this.load();
      },
    );
  }

  ngOnInit(): void {
    this.restoreFromUrl();
    if (this.profileReady) this.load();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes["preset"]?.currentValue) {
      this.applyPreset(changes["preset"].currentValue);
    }
    if (changes["profileReady"]?.currentValue === true) this.load();
  }

  ngOnDestroy(): void {
    this.loadSubscription?.unsubscribe();
    this.detailsSubscription?.unsubscribe();
    this.realtimeSubscription.unsubscribe();
  }

  setQuickFilter(value: QuickFilter): void {
    this.quickFilter = value;
    this.statusFilter = this.statusForQuickFilter(value);
    this.applyFilters();
  }

  setReservationTypeFilter(value: ReservationTypeFilter): void {
    this.reservationTypeFilter = value;
    this.applyFilters();
  }

  applyFilters(): void {
    this.pageNumber = 1;
    this.syncUrl();
    this.load();
  }

  searchReservations(): void {
    this.searchText = this.searchText.trim();
    this.consultantName = this.consultantName.trim();
    this.applyFilters();
  }

  onReservationStatusChange(event: Event): void {
    this.reservationStatus = (event.target as HTMLSelectElement).value;
    this.applyFilters();
  }

  clearFilters(): void {
    this.quickFilter = "all";
    this.searchText = "";
    this.consultantName = "";
    this.statusFilter = null;
    this.reservationStatus = "";
    this.secretaryAnnouncementFilter = null;
    this.reservationDate = null;
    this.fromDate = null;
    this.toDate = null;
    this.sortDirection = "asc";
    this.reservationTypeFilter = "all";
    this.applyFilters();
  }

  clearDateFilters(): void {
    this.reservationDate = null;
    this.fromDate = null;
    this.toDate = null;
    this.applyFilters();
  }

  setDateFilterMode(mode: "exact" | "range"): void {
    this.dateFilterMode = mode;
    if (mode === "exact") {
      this.fromDate = null;
      this.toDate = null;
    } else {
      this.reservationDate = null;
    }
  }

  dateFilterLabel(): string {
    const activeCount = [
      this.reservationDate,
      this.fromDate,
      this.toDate,
    ].filter(Boolean).length;
    if (!activeCount) return "فیلتر تاریخ";
    if (this.reservationDate) return "تاریخ رزرو انتخاب شده";
    return activeCount === 2 ? "بازه تاریخ انتخاب شده" : "یک تاریخ انتخاب شده";
  }

  changePageSize(): void {
    this.pageNumber = 1;
    this.syncUrl();
    this.load();
  }

  goToPage(page: number): void {
    if (page < 1 || page > this.totalPages || page === this.pageNumber) return;
    this.pageNumber = page;
    this.syncUrl();
    this.load();
  }

  load(): void {
    if (!this.profileReady) return;

    const currentRequest = ++this.requestId;
    const exactDate = this.toDateParam(this.reservationDate);
    const rangeFrom = exactDate ?? this.toDateParam(this.fromDate);
    const rangeTo = exactDate ?? this.toDateParam(this.toDate);
    this.loading = true;
    this.errorMessage = "";
    this.loadSubscription?.unsubscribe();

    this.loadSubscription = this.api
      .getReservations({
        pageNumber: this.pageNumber,
        pageSize: this.pageSize,
        includeCanceled: true,
        searchText: this.searchText.trim() || undefined,
        consultantName: this.consultantName.trim() || undefined,
        reservationStatus: this.reservationStatus || null,
        secretaryAnnouncementStatus: this.secretaryAnnouncementFilter,
        attendanceConfirmationStatus: this.statusFilter,
        // The current backend binds the range from fromDate/toDate. Keep the
        // former from/to names too so this frontend remains safe during rollout.
        reservationDate: exactDate,
        fromDate: rangeFrom,
        toDate: rangeTo,
        from: rangeFrom,
        to: rangeTo,
        sortDirection: this.sortDirection,
        reservationType:
          this.reservationTypeFilter === "regular"
            ? ReservationType.Regular
            : this.reservationTypeFilter === "after-sales"
              ? ReservationType.AfterSalesService
              : null,
      })
      .pipe(
        finalize(() => {
          if (currentRequest !== this.requestId) return;
          this.loading = false;
          this.cdr.markForCheck();
        }),
      )
      .subscribe({
        next: (response) => {
          if (currentRequest !== this.requestId) return;
          this.items = response.items ?? [];
          this.totalCount = response.totalCount ?? 0;
          this.pageNumber = response.pageNumber || 1;
          this.totalPages = Math.max(1, response.totalPages || 1);
          this.cdr.markForCheck();
        },
        error: (error) => {
          if (currentRequest !== this.requestId) return;
          this.items = [];
          this.totalCount = 0;
          this.errorMessage = this.errorText(
            error,
            "دریافت درخواست‌های رزرو انجام نشد",
          );
          this.cdr.markForCheck();
        },
      });
  }

  openDialog(item: SecretaryReservation, mode: DialogMode): void {
    if (mode !== "details" && !this.hasManagementAccess(item)) return;
    this.selected = item;
    this.dialogMode = mode;
    this.detailsError = "";
    this.note = "";
    this.reasonCode = null;
    this.rejectionText = "";
    this.newDate = null;
    this.newTime = "";
    if (mode === "reschedule") {
      const reservationDate = new Date(this.reservationAt(item));
      if (Number.isFinite(reservationDate.getTime())) {
        this.newDate = reservationDate;
        this.newTime = toIranTimeInputValue(reservationDate);
      }
    }
    this.editDentalServices = dentalServicesOf(item);
    this.editPatientCount = reservationPatientCount(item);
    this.contactResult = this.secretaryAnnouncementStatus(item);

    if (mode === "details") this.loadSelectedDetails(item);
  }

  closeDialog(): void {
    if (this.saving) return;
    this.dialogMode = null;
    this.selected = null;
    this.detailsLoading = false;
    this.detailsError = "";
    this.detailsSubscription?.unsubscribe();
    this.detailsSubscription = null;
  }

  private loadSelectedDetails(item: SecretaryReservation): void {
    const id = this.reservationId(item);
    if (!id) return;

    this.detailsLoading = true;
    this.detailsSubscription?.unsubscribe();
    this.detailsSubscription = this.api.getReservationDetails(id)
      .pipe(finalize(() => {
        this.detailsLoading = false;
        this.cdr.markForCheck();
      }))
      .subscribe({
        next: (details) => {
          if (
            this.dialogMode !== "details" ||
            !this.selected ||
            this.reservationId(this.selected) !== id
          ) return;
          // List endpoints return a compact projection while the details endpoint
          // contains the remaining workflow states. Preserve list values when a
          // field is absent from the detailed projection.
          this.selected = { ...item, ...details };
          this.cdr.markForCheck();
        },
        error: (error) => {
          this.detailsError = this.errorText(error, "دریافت همه جزئیات رزرو انجام نشد");
          this.cdr.markForCheck();
        },
      });
  }

  openCreateDialog(type = ReservationType.AfterSalesService): void {
    if (!this.canCreate) return;
    this.createReservationType = type;
    this.createLeadAssignmentId = null;
    this.createConsultantProfileId = null;
    this.createDate = null;
    this.createTime = "";
    this.createDescription = "";
    this.createServiceTitle = "";
    this.createDentalServices = [];
    this.patientSearch = "";
    this.createDialogOpen = true;
    this.loadCreateOptions();
  }

  closeCreateDialog(): void {
    if (!this.saving) this.createDialogOpen = false;
  }

  createReservation(): void {
    if (!this.canCreate || this.saving) return;
    if (!this.createLeadAssignmentId || !this.createConsultantProfileId) {
      this.toast.error("ابتدا بیماری را انتخاب کنید که مشاور فعال دارد");
      return;
    }
    if (!this.createDate || !this.createTime) {
      this.toast.error("تاریخ و ساعت مراجعه الزامی است");
      return;
    }
    if (!this.createDentalServices.length) {
      this.toast.error("انتخاب حداقل یک خدمت معتبر الزامی است");
      return;
    }
    if (!this.createServiceTitle.trim()) {
      this.toast.error("عنوان خدمت پس از فروش الزامی است");
      return;
    }
    const reservationAt = this.combineDateTime(this.createDate, this.createTime);
    this.saving = true;
    this.api.createReservation({
      leadAssignmentId: this.createLeadAssignmentId,
      consultantProfileId: this.createConsultantProfileId,
      reservationAt,
      description: [
        `خدمت: ${this.createServiceTitle.trim()}`,
        this.createDescription.trim(),
      ].filter(Boolean).join("\n"),
      reservationType: this.createReservationType,
      dentalServices: this.createDentalServices,
    }).pipe(finalize(() => { this.saving = false; this.cdr.markForCheck(); }))
      .subscribe({
        next: (response) => {
          this.toast.success(response.message || "رزرو با موفقیت ثبت شد");
          this.createDialogOpen = false;
          this.reservationSync.requestRefresh();
          this.load();
        },
        error: (error) => this.toast.error(this.errorText(error, "ثبت رزرو انجام نشد")),
      });
  }

  toggleCreateDentalService(service: number, checked: boolean): void {
    const selected = new Set(this.createDentalServices);
    checked ? selected.add(service) : selected.delete(service);
    this.createDentalServices = [...selected];
  }

  loadCreateOptions(): void {
    if (this.createOptionsLoading) return;
    this.createOptionsLoading = true;
    this.createOptionsError = "";
    this.api.getPatientOptions().pipe(finalize(() => {
      this.createOptionsLoading = false;
      this.cdr.markForCheck();
    })).subscribe({
      next: (patients) => {
        this.patientOptions = patients;
        this.cdr.markForCheck();
      },
      error: (error) => {
        this.createOptionsError = this.errorText(
          error,
          "دریافت فهرست بیماران انجام نشد",
        );
        this.cdr.markForCheck();
      },
    });
  }

  get filteredPatientOptions(): SecretaryPatientOption[] {
    const query = this.normalizeSearch(this.patientSearch);
    if (!query) return this.patientOptions;
    return this.patientOptions.filter((item) =>
      this.normalizeSearch(`${this.patientOptionName(item)} ${this.patientOptionPhone(item)}`).includes(query),
    );
  }

  patientOptionId(item: SecretaryPatientOption): number {
    return Number(item.leadAssignmentId ?? item.LeadAssignmentId ?? item.id ?? item.Id);
  }

  patientOptionName(item: SecretaryPatientOption): string {
    const person = item.user ?? item.User ?? item.lead ?? item.Lead ?? {};
    const fullName = item.fullName?.trim() || item.FullName?.trim();
    const composedName = [
      item.firstName ?? item.FirstName ?? person["firstName"] ?? person["FirstName"],
      item.lastName ?? item.LastName ?? person["lastName"] ?? person["LastName"],
    ].filter(Boolean).join(" ").trim();
    return fullName || composedName || item.userName || item.UserName || "بیمار بدون نام";
  }

  patientOptionPhone(item: SecretaryPatientOption): string {
    const person = item.user ?? item.User ?? item.lead ?? item.Lead ?? {};
    return String(item.phoneNumber ?? item.PhoneNumber ?? person["phoneNumber"] ?? person["PhoneNumber"] ?? "");
  }

  onPatientSelected(leadAssignmentId: number | null): void {
    this.createLeadAssignmentId = leadAssignmentId;
    const patient = this.selectedPatientOption;
    this.createConsultantProfileId = patient
      ? this.patientConsultantId(patient)
      : null;
  }

  get selectedPatientOption(): SecretaryPatientOption | null {
    if (!this.createLeadAssignmentId) return null;
    return this.patientOptions.find(
      (item) => this.patientOptionId(item) === this.createLeadAssignmentId,
    ) ?? null;
  }

  patientConsultantId(item: SecretaryPatientOption): number | null {
    const consultant = item.consultant ?? item.Consultant ?? {};
    const value = Number(
      item.consultantProfileId ??
      item.ConsultantProfileId ??
      consultant["profileId"] ??
      consultant["ProfileId"] ??
      consultant["consultantProfileId"] ??
      consultant["ConsultantProfileId"],
    );
    return Number.isFinite(value) && value > 0 ? value : null;
  }

  patientConsultantName(item: SecretaryPatientOption): string {
    const consultant = item.consultant ?? item.Consultant ?? {};
    const fullName = item.consultantFullName?.trim() ||
      item.ConsultantFullName?.trim() ||
      String(consultant["fullName"] ?? consultant["FullName"] ?? "").trim();
    const composedName = [
      consultant["firstName"] ?? consultant["FirstName"],
      consultant["lastName"] ?? consultant["LastName"],
    ].filter(Boolean).join(" ").trim();
    return fullName || composedName || "مشاور ثبت نشده";
  }

  patientConsultantPhone(item: SecretaryPatientOption): string {
    const consultant = item.consultant ?? item.Consultant ?? {};
    return String(
      item.consultantPhoneNumber ??
      item.ConsultantPhoneNumber ??
      consultant["phoneNumber"] ??
      consultant["PhoneNumber"] ??
      "",
    );
  }

  private normalizeSearch(value: string): string {
    return value.toLocaleLowerCase("fa").replaceAll("ي", "ی").replaceAll("ك", "ک").trim();
  }

  submitDialog(): void {
    const item = this.selected;
    const id = item ? this.reservationId(item) : null;
    if (
      !item ||
      !id ||
      !this.dialogMode ||
      this.dialogMode === "details" ||
      !this.hasManagementAccess(item)
    )
      return;
    const validation = this.validateDialog(item);
    if (validation) {
      this.toast.error(validation);
      return;
    }

    let request;
    if (this.dialogMode === "confirm") {
      request = this.api.confirmReservation(id, this.note.trim() || null);
    } else if (this.dialogMode === "reschedule") {
      request = this.api.updateReservationTime(
        id,
        this.combineDateTime(this.newDate!, this.newTime),
        this.editDentalServices,
        this.editPatientCount,
      );
    } else if (this.dialogMode === "reject") {
      request = this.api.rejectReservation(id, {
        reasonCode: this.reasonCode!,
        reason: this.resolvedRejectionReason(),
      });
    } else if (this.dialogMode === "contact") {
      const secretaryUserId = this.auth.user()?.userId;
      if (!secretaryUserId) {
        this.toast.error("شناسه کاربر منشی در دسترس نیست؛ لطفاً دوباره وارد شوید");
        return;
      }
      request = this.api.updateSecretaryAnnouncement({
        reservationId: id,
        secretaryUserId,
        status: this.contactResult,
        description: this.note.trim() || null,
      });
    } else {
      request = this.api.recordVisitResult(
        id,
        this.visitResult,
        this.note.trim() || null,
      );
    }

    this.saving = true;
    request
      .pipe(
        finalize(() => {
          this.saving = false;
          this.cdr.markForCheck();
        }),
      )
      .subscribe({
        next: (response) => {
          this.saving = false;
          this.toast.success(response.message || "عملیات با موفقیت ثبت شد");
          this.closeDialog();
          this.reservationSync.requestRefresh();
          this.load();
        },
        error: (error) =>
          this.toast.error(this.errorText(error, "ثبت عملیات انجام نشد")),
      });
  }

  canManage(item: SecretaryReservation): boolean {
    return (
      this.hasManagementAccess(item) &&
      this.status(item) === ReservationRequestStatus.PendingSecretaryReview
    );
  }

  hasManagementAccess(item: SecretaryReservation): boolean {
    return this.api.canManageReservation(item);
  }

  canChangeTime(item: SecretaryReservation): boolean {
    return (
      this.hasManagementAccess(item) &&
      !(item.isCanceled ?? item.IsCanceled ?? false)
    );
  }

  canRecordVisit(item: SecretaryReservation): boolean {
    return (
      this.hasManagementAccess(item) &&
      [
        ReservationRequestStatus.Confirmed,
        ReservationRequestStatus.Rescheduled,
      ].includes(this.status(item) as ReservationRequestStatus)
    );
  }

  phoneHref(item: SecretaryReservation): string | null {
    const phone = this.patientPhone(item).replace(/[^\d+]/g, "");
    return phone && phone !== "-" ? `tel:${phone}` : null;
  }

  statusLabel(item: SecretaryReservation): string {
    return attendanceStatusPresentation(this.attendanceStatus(item)).label;
  }

  statusClass(item: SecretaryReservation): string {
    return attendanceStatusPresentation(this.attendanceStatus(item)).badgeClass;
  }

  secretaryAnnouncementStatus(item: SecretaryReservation): SecretaryAnnouncementStatus {
    return item.secretaryAnnouncementStatus ?? item.SecretaryAnnouncementStatus ?? "NotCalled";
  }

  secretaryAnnouncementLabel(item: SecretaryReservation): string {
    const status = this.secretaryAnnouncementStatus(item);
    if (status === "Confirmed") return "🟢 تایید شده";
    if (status === "NoAnswer") return "🟠 پاسخ نداد";
    if (status === "CancelledByPatient") return "🔴 لغو شده";
    if (status === "NotCalled") return "⚪ تماس نشده";
    return SECRETARY_ANNOUNCEMENT_OPTIONS.find((option) => option.value === status)?.label ?? status;
  }

  secretaryAnnouncementClass(item: SecretaryReservation): string {
    const status = this.secretaryAnnouncementStatus(item);
    return status === "Confirmed" ? "success" : status === "CancelledByPatient" ? "danger" : status === "NoAnswer" ? "warn" : "muted";
  }

  reservationId(item: SecretaryReservation): number | null {
    const value = Number(item.id ?? item.Id);
    return Number.isFinite(value) ? value : null;
  }
  patientName(item: SecretaryReservation): string {
    return (
      item.patientName?.trim() || item.PatientName?.trim() || "بیمار بدون نام"
    );
  }
  patientPhone(item: SecretaryReservation): string {
    return (
      item.patientPhoneNumber?.trim() || item.PatientPhoneNumber?.trim() || "-"
    );
  }
  consultantNameOf(item: SecretaryReservation): string {
    return (
      item.consultantFullName?.trim() || item.ConsultantFullName?.trim() || "-"
    );
  }
  serviceName(item: SecretaryReservation): string {
    return (
      item.requestedServiceName?.trim() ||
      item.RequestedServiceName?.trim() ||
      item.businessName?.trim() ||
      item.BusinessName?.trim() ||
      "ثبت نشده"
    );
  }
  consultantReport(item: SecretaryReservation): string {
    return (
      item.consultantReport?.trim() ||
      item.ConsultantReport?.trim() ||
      item.description?.trim() ||
      item.Description?.trim() ||
      "گزارشی ثبت نشده"
    );
  }
  doctorRoom(item: SecretaryReservation): string | null {
    const doctor = item.doctorName ?? item.DoctorName;
    const room = item.roomName ?? item.RoomName;
    return doctor || room ? `${doctor ?? "-"} / ${room ?? "-"}` : null;
  }
  reservationAt(item: SecretaryReservation): string {
    return item.reservationAt || item.ReservationAt || "";
  }
  formatDate(value?: string | null): string {
    if (!value) return "-";
    const date = new Date(value);
    return Number.isFinite(date.getTime())
      ? new Intl.DateTimeFormat("fa-IR", {
          dateStyle: "medium",
          timeStyle: "short",
          timeZone: "Asia/Tehran",
        }).format(date)
      : "-";
  }
  formatAppointmentTime(value?: string | null): string {
    return formatReservationTime(value);
  }
  displayReservationAt(item: SecretaryReservation): string {
    return item.reservationAtPersian ?? item.ReservationAtPersian ??
      this.formatAppointmentTime(this.reservationAt(item));
  }
  displayCreatedAt(item: SecretaryReservation): string {
    return item.createdAtPersian ?? item.CreatedAtPersian ??
      this.formatDate(item.createdAt ?? item.CreatedAt ?? item.requestCreatedAt);
  }

  private status(item: SecretaryReservation): number {
    return Number(
      item.reservationRequestStatus ??
        item.secretaryReservationReviewStatus ??
        item.SecretaryReservationReviewStatus ??
        0,
    );
  }

  private attendanceStatus(
    item: SecretaryReservation,
  ): AttendanceConfirmationStatus | null {
    return readAttendanceStatus(item, "attendanceConfirmationStatus");
  }

  private validateDialog(item: SecretaryReservation): string | null {
    if (this.dialogMode === "reschedule") {
      const patientCountError = validatePatientCount(this.editPatientCount);
      if (patientCountError) return patientCountError;
      if (!this.editDentalServices.length)
        return "انتخاب حداقل یک خدمت معتبر الزامی است";
      if (!this.newDate || !this.newTime) return "تاریخ و ساعت جدید الزامی است";
      const next = new Date(
        this.combineDateTime(this.newDate, this.newTime),
      ).getTime();
      if (!Number.isFinite(next) || next <= Date.now())
        return "زمان جدید باید معتبر و در آینده باشد";
      if (Math.abs(next - new Date(this.reservationAt(item)).getTime()) < 60000)
        return "زمان جدید باید با زمان فعلی متفاوت باشد";
    }
    if (this.dialogMode === "reject") {
      if (!this.reasonCode) return "انتخاب دلیل رد الزامی است";
      if (this.reasonCode === 4 && !this.rejectionText.trim())
        return "توضیحات دلیل سایر الزامی است";
    }
    return null;
  }

  toggleEditDentalService(service: number, checked: boolean): void {
    const selected = new Set(this.editDentalServices);
    checked ? selected.add(service) : selected.delete(service);
    this.editDentalServices = [...selected];
  }

  private resolvedRejectionReason(): string {
    return this.reasonCode === 1
      ? "عدم ظرفیت"
      : this.reasonCode === 2
        ? "عدم پاسخ بیمار"
        : this.reasonCode === 3
          ? "درخواست لغو شده"
          : this.rejectionText.trim();
  }

  private combineDateTime(date: Date, time: string): string {
    const [hours, minutes] = time.split(":").map(Number);
    const value = new Date(date);
    value.setHours(hours, minutes, 0, 0);
    return value.toISOString();
  }

  private statusForQuickFilter(
    filter: QuickFilter,
  ): AttendanceConfirmationStatus | null {
    return filter === "pending"
      ? AttendanceConfirmationStatus.PendingConsultantConfirmation
      : filter === "confirmed"
        ? AttendanceConfirmationStatus.SecretaryApproved
        : filter === "followup"
          ? null
          : filter === "rejected"
            ? AttendanceConfirmationStatus.SecretaryRejected
            : null;
  }

  private applyPreset(preset: SecretaryDashboardPreset): void {
    this.preset = preset;
    this.quickFilter = "all";
    this.statusFilter = null;
    this.reservationTypeFilter = preset === "after-sales" ? "after-sales" : "all";
    this.secretaryAnnouncementFilter = preset === "after-sales" ? null :
      preset === "secretary-confirmed" ? "Confirmed" :
      preset === "secretary-no-answer" ? "NoAnswer" :
      preset === "secretary-cancelled" ? "CancelledByPatient" : "NotCalled";
    this.applyFilters();
  }

  private restoreFromUrl(): void {
    const params = this.route.snapshot.queryParamMap;
    const filter = params.get("requestFilter") as QuickFilter | null;
    const restoredStatus = Number(params.get("attendanceStatus"));
    this.statusFilter =
      params.has("attendanceStatus") &&
      STATUS_OPTIONS.some((option) => option.value === restoredStatus)
        ? (restoredStatus as AttendanceConfirmationStatus)
        : this.statusForQuickFilter(this.quickFilter);
    this.searchText = params.get("requestSearch") ?? "";
    this.consultantName = params.get("consultant") ?? "";
    this.reservationStatus = params.get("reservationStatus") ?? "";
    const announcement = params.get("secretaryAnnouncementStatus") as SecretaryAnnouncementStatus | null;
    this.secretaryAnnouncementFilter = SECRETARY_ANNOUNCEMENT_OPTIONS.some((option) => option.value === announcement) ? announcement : null;
    this.reservationDate = this.readDateParam(params.get("reservationDate"));
    this.fromDate = this.readDateParam(params.get("requestFrom"));
    this.toDate = this.readDateParam(params.get("requestTo"));
    this.dateFilterMode = this.fromDate || this.toDate ? "range" : "exact";
    this.sortDirection =
      params.get("requestDirection") === "desc" ? "desc" : "asc";
    const type = params.get("reservationType") as ReservationTypeFilter | null;
    this.reservationTypeFilter = ["regular", "after-sales"].includes(type ?? "") ? type! : "all";
    this.pageNumber = Math.max(1, Number(params.get("requestPage")) || 1);
    this.pageSize = [10, 20, 50].includes(Number(params.get("requestPageSize")))
      ? Number(params.get("requestPageSize"))
      : 20;
  }

  private syncUrl(): void {
    void this.router.navigate([], {
      relativeTo: this.route,
      queryParamsHandling: "merge",
      replaceUrl: true,
      queryParams: {
        requestFilter: this.quickFilter === "all" ? null : this.quickFilter,
        requestStatus: null,
        attendanceStatus: this.statusFilter,
        requestSearch: this.searchText.trim() || null,
        consultant: this.consultantName.trim() || null,
        reservationStatus: this.reservationStatus || null,
        secretaryAnnouncementStatus: this.secretaryAnnouncementFilter,
        reservationDate: this.toDateParam(this.reservationDate) ?? null,
        requestFrom: this.toDateParam(this.fromDate) ?? null,
        requestTo: this.toDateParam(this.toDate) ?? null,
        requestSort: null,
        requestDirection:
          this.sortDirection !== "asc" ? this.sortDirection : null,
        reservationType: this.reservationTypeFilter === "all" ? null : this.reservationTypeFilter,
        requestPage: this.pageNumber > 1 ? this.pageNumber : null,
        requestPageSize: this.pageSize !== 20 ? this.pageSize : null,
      },
    });
  }

  private toDateParam(value: Date | null): string | undefined {
    if (!value) return undefined;

    // A calendar date has no timezone. Using toISOString() here converted the
    // user's local midnight to UTC and could send the previous day to the API.
    const year = value.getFullYear();
    const month = `${value.getMonth() + 1}`.padStart(2, "0");
    const day = `${value.getDate()}`.padStart(2, "0");
    return `${year}-${month}-${day}`;
  }
  private readDateParam(value: string | null): Date | null {
    if (!value) return null;
    const date = new Date(`${value}T12:00:00`);
    return Number.isFinite(date.getTime()) ? date : null;
  }
  private todayParam(): string {
    return new Date().toLocaleDateString("en-CA", { timeZone: "Asia/Tehran" });
  }
  private errorText(error: unknown, fallback: string): string {
    return error instanceof Error && error.message ? error.message : fallback;
  }
}
