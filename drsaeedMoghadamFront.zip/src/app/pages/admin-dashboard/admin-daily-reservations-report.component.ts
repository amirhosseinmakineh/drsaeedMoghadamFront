import { CommonModule } from "@angular/common";
import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { finalize } from "rxjs";
import {
  AdminDashboardService,
  AdminUser,
  Consultant,
  DailyReservationReportItem,
  DailyReservationsReport,
  DailyReservationsReportFilters,
} from "../../core/admin/admin-dashboard.service";
import { ToastService } from "../../core/toast/toast.service";
import { BaseDatepickerComponent } from "../../shared/base/base-datepicker/base-datepicker.component";
import { downloadBlob } from "../../utils/file-download.util";
import { formatDentalServices } from "../../core/reservation/dental-services";
import {
  formatIranDateTime,
  formatReservationTime,
  nowInIran,
  toIranDateInputValue,
} from "../../utils/iran-datetime.util";

@Component({
  selector: "app-admin-daily-reservations-report",
  standalone: true,
  imports: [CommonModule, FormsModule, BaseDatepickerComponent],
  templateUrl: "./admin-daily-reservations-report.component.html",
  styleUrl: "./admin-daily-reservations-report.component.scss",
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AdminDailyReservationsReportComponent implements OnInit {
  readonly dentalServicesLabel = formatDentalServices;
  selectedDate = nowInIran();
  consultantProfileId: number | null = null;
  reservationOwnerType: "Consultant" | "Secretary" = "Consultant";
  secretaryUserId: string | null = null;
  requestStatus: number | null = null;
  includeAllReservations = false;
  consultants: Consultant[] = [];
  consultantsLoading = false;
  consultantsLoadError = "";
  secretaries: AdminUser[] = [];
  secretariesLoading = false;
  secretariesLoadError = "";
  report: DailyReservationsReport | null = null;
  loading = false;
  downloading = false;
  errorMessage = "";

  readonly createdDatePickerLabel = { fa: "تاریخ ثبت رزرو", en: "Created date" };
  readonly appointmentDatePickerLabel = { fa: "تاریخ مراجعه", en: "Appointment date" };
  readonly requestStatuses = [
    { value: 1, label: "در انتظار بررسی منشی" },
    { value: 2, label: "تایید شده" },
    { value: 3, label: "زمان‌بندی مجدد" },
    { value: 4, label: "رد شده" },
    { value: 5, label: "لغو شده" },
    { value: 6, label: "در انتظار تایید بیمار" },
    { value: 7, label: "نیازمند پیگیری" },
  ];

  constructor(
    private readonly adminApi: AdminDashboardService,
    private readonly toast: ToastService,
    private readonly cdr: ChangeDetectorRef,
  ) {}

  ngOnInit(): void {
    this.loadConsultants(true);
    this.loadSecretaries(true);
    this.loadReport();
  }

  setDate(date: Date): void {
    this.selectedDate = date;
    this.cdr.markForCheck();
  }

  setReservationOwnerType(type: "Consultant" | "Secretary"): void {
    this.reservationOwnerType = type;
    this.consultantProfileId = null;
    this.secretaryUserId = null;
    if (type === "Consultant") {
      this.loadConsultants();
    } else {
      this.loadSecretaries();
    }
    this.cdr.markForCheck();
  }

  setIncludeAllReservations(includeAll: boolean): void {
    this.includeAllReservations = includeAll;
    this.cdr.markForCheck();
    this.loadReport();
  }

  loadReport(): void {
    if (this.loading) return;
    this.loading = true;
    this.errorMessage = "";
    this.cdr.markForCheck();
    this.adminApi
      .getDailyReservationsReport(this.filters())
      .pipe(finalize(() => { this.loading = false; this.cdr.markForCheck(); }))
      .subscribe({
        next: (report) => { this.report = report; this.cdr.markForCheck(); },
        error: (error) => {
          this.errorMessage = this.errorText(error);
          this.toast.error(this.errorMessage);
          this.cdr.markForCheck();
        },
      });
  }

  download(): void {
    if (this.downloading) return;
    const filters = this.filters();
    this.downloading = true;
    this.cdr.markForCheck();
    this.adminApi
      .exportDailyReservationsReport(filters)
      .pipe(finalize(() => { this.downloading = false; this.cdr.markForCheck(); }))
      .subscribe({
        next: (blob) => {
          const suffix = filters.includeAll
            ? "all"
            : filters.date!.replaceAll("-", "");
          downloadBlob(blob, `daily-reservations-${suffix}.csv`);
          this.toast.success("فایل گزارش روزانه رزروها دانلود شد");
        },
        error: (error) => this.toast.error(this.errorText(error)),
      });
  }

  formatDateTime(value: string | null | undefined): string {
    return formatIranDateTime(value);
  }

  formatAppointmentTime(value: string | null | undefined): string {
    return formatReservationTime(value);
  }

  secretaryAnnouncement(item: DailyReservationReportItem): string {
    return (
      item.secretaryAnnouncement?.trim() ||
      item.SecretaryAnnouncement?.trim() ||
      item.secretaryAnnouncementDescription?.trim() ||
      item.SecretaryAnnouncementDescription?.trim() ||
      this.secretaryAnnouncementStatusLabel(
        item.secretaryAnnouncementStatus ?? item.SecretaryAnnouncementStatus,
      )
    );
  }

  private secretaryAnnouncementStatusLabel(status: string | null | undefined): string {
    if (status === "Confirmed") return "تایید شده";
    if (status === "NoAnswer") return "پاسخ نداد";
    if (status === "CancelledByPatient") return "لغو توسط بیمار";
    if (status === "RescheduleRequested") return "درخواست تغییر زمان";
    if (status === "CallAgain") return "تماس مجدد";
    if (status === "NotCalled") return "تماس نشده";
    return status?.trim() || "-";
  }

  trackReservation(_: number, item: DailyReservationReportItem): number {
    return item.reservationId;
  }

  consultantId(consultant: Consultant): number {
    return consultant.profileId ?? consultant.ProfileId!;
  }

  consultantName(consultant: Consultant): string {
    const fullName = [
      consultant.firstName || consultant.FirstName,
      consultant.lastName || consultant.LastName,
    ].filter(Boolean).join(" ");
    return fullName || `مشاور ${this.consultantId(consultant)}`;
  }

  secretaryId(secretary: AdminUser): string {
    return secretary.id || secretary.Id || "";
  }

  secretaryName(secretary: AdminUser): string {
    const fullName = [
      secretary.firstName || secretary.FirstName,
      secretary.lastName || secretary.LastName,
    ].filter(Boolean).join(" ");
    return fullName || secretary.phoneNumber || secretary.PhoneNumber || "منشی";
  }

  private filters(): DailyReservationsReportFilters {
    if (this.includeAllReservations) {
      return { includeAll: true };
    }

    return {
      date: toIranDateInputValue(this.selectedDate),
      reservationOwnerType: this.reservationOwnerType,
      ...(this.reservationOwnerType === "Consultant" &&
      this.consultantProfileId !== null
        ? { consultantProfileId: this.consultantProfileId }
        : {}),
      ...(this.reservationOwnerType === "Secretary" && this.secretaryUserId
        ? { secretaryUserId: this.secretaryUserId }
        : {}),
      ...(this.requestStatus ? { requestStatus: this.requestStatus } : {}),
    };
  }

  loadConsultants(force = false): void {
    if (this.consultantsLoading) return;
    if (!force && this.consultants.length) return;

    this.consultantsLoading = true;
    this.consultantsLoadError = "";
    this.cdr.markForCheck();
    this.adminApi
      .getConsultantsList({ pageNumber: 1, pageSize: 500 })
      .pipe(finalize(() => {
        this.consultantsLoading = false;
        this.cdr.markForCheck();
      }))
      .subscribe({
        next: ({ items }) => {
          this.consultants = items.filter((item) =>
            Number.isFinite(this.consultantId(item)),
          );
          this.cdr.markForCheck();
        },
        error: (error) => {
          this.consultantsLoadError = this.errorText(error);
          this.toast.error(this.consultantsLoadError);
          this.cdr.markForCheck();
        },
      });
  }
  loadSecretaries(force = false): void {
    if (this.secretariesLoading) return;
    if (!force && this.secretaries.length) return;

    this.secretariesLoading = true;
    this.secretariesLoadError = "";
    this.cdr.markForCheck();
    this.adminApi
      .getSecretaries({ pageNumber: 1, pageSize: 500 })
      .pipe(finalize(() => {
        this.secretariesLoading = false;
        this.cdr.markForCheck();
      }))
      .subscribe({
        next: ({ items }) => {
          this.secretaries = items.filter((item) => !!this.secretaryId(item));
          this.cdr.markForCheck();
        },
        error: (error) => {
          this.secretariesLoadError = this.errorText(error);
          this.toast.error(this.secretariesLoadError);
          this.cdr.markForCheck();
        },
      });
  }

  private errorText(error: unknown): string {
    return error instanceof Error && error.message
      ? error.message
      : "خطا در دریافت گزارش. لطفاً دوباره تلاش کنید.";
  }
}
