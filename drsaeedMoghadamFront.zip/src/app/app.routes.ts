import { Routes } from "@angular/router";
import {
  authGuard,
  dashboardRedirectGuard,
  roleGuard,
} from "./core/auth/auth.guard";

export const routes: Routes = [
  {
    path: "",
    loadComponent: () =>
      import("./pages/home/home.component").then((m) => m.HomeComponent),
  },
  {
    path: "services",
    loadComponent: () =>
      import("./pages/services/services.component").then(
        (m) => m.ServicesComponent,
      ),
  },
  {
    path: "services/:id",
    loadComponent: () =>
      import("./pages/service-detail/service-detail.component").then(
        (m) => m.ServiceDetailComponent,
      ),
  },
  {
    path: "composite",
    loadComponent: () =>
      import("./pages/service-detail/service-detail.component").then(
        (m) => m.ServiceDetailComponent,
      ),
    data: { serviceId: "composite" },
  },
  {
    path: "bleaching",
    loadComponent: () =>
      import("./pages/service-detail/service-detail.component").then(
        (m) => m.ServiceDetailComponent,
      ),
    data: { serviceId: "whitening" },
  },
  {
    path: "about",
    loadComponent: () =>
      import("./pages/about/about.component").then((m) => m.AboutComponent),
  },
  {
    path: "contact",
    loadComponent: () =>
      import("./pages/contact/contact.component").then(
        (m) => m.ContactComponent,
      ),
  },
  {
    path: "select-dashboard",
    canActivate: [authGuard],
    loadComponent: () =>
      import("./pages/select-dashboard/select-dashboard.component").then(
        (m) => m.SelectDashboardComponent,
      ),
  },
  {
    path: "dashboard",
    canActivate: [authGuard, dashboardRedirectGuard],
    loadComponent: () =>
      import("./pages/dashboard/dashboard.component").then(
        (m) => m.DashboardComponent,
      ),
  },
  {
    path: "dashboard/admin",
    canActivate: [authGuard, roleGuard(["admin"])],
    loadComponent: () =>
      import("./pages/dashboard/dashboard.component").then(
        (m) => m.DashboardComponent,
      ),
    data: { role: "admin" },
  },
  {
    path: "dashboard/consultant",
    canActivate: [authGuard, roleGuard(["consultant"])],
    loadComponent: () =>
      import("./pages/consultant-dashboard/consultant-dashboard.component").then(
        (m) => m.ConsultantDashboardComponent,
      ),
    data: { role: "consultant" },
  },
  {
    path: "consultant/leads",
    canActivate: [authGuard, roleGuard(["consultant"])],
    loadComponent: () =>
      import("./pages/consultant-dashboard/consultant-dashboard.component").then(
        (m) => m.ConsultantDashboardComponent,
      ),
    data: { role: "consultant", initialSection: "leads" },
  },
  {
    path: "consultant/wallet",
    canActivate: [authGuard, roleGuard(["consultant"])],
    loadComponent: () =>
      import("./pages/consultant-dashboard/consultant-dashboard.component").then(
        (m) => m.ConsultantDashboardComponent,
      ),
    data: { role: "consultant", initialSection: "wallet" },
  },
  {
    path: "dashboard/secretary",
    canActivate: [authGuard, roleGuard(["secretary"])],
    loadComponent: () =>
      import("./pages/secretary-dashboard/secretary-dashboard.component").then(
        (m) => m.SecretaryDashboardComponent,
      ),
    data: { role: "secretary" },
  },
  {
    path: "secretary/reservation-attendance-reviews",
    redirectTo: "dashboard/secretary",
    pathMatch: "full",
  },
  {
    path: "secretary/patient-finance",
    canActivate: [authGuard, roleGuard(["secretary"])],
    loadComponent: () =>
      import("./features/secretary/patient-finance/pages/patient-finance-page/patient-finance-page.component").then(
        (m) => m.PatientFinancePageComponent,
      ),
  },
  {
    path: "secretary/accounting/patient-files",
    canActivate: [authGuard, roleGuard(["secretary"])],
    loadComponent: () =>
      import("./features/secretary/patient-files/patient-files-page.component").then(
        (m) => m.PatientFilesPageComponent,
      ),
  },
  {
    path: "secretary/account",
    canActivate: [authGuard, roleGuard(["secretary"])],
    loadChildren: () =>
      import("./features/secretary/account/secretary-account.routes").then(
        (m) => m.SECRETARY_ACCOUNT_ROUTES,
      ),
  },
  {
    path: "dashboard/patient",
    canActivate: [authGuard, roleGuard(["patient"])],
    loadComponent: () =>
      import("./pages/dashboard/dashboard.component").then(
        (m) => m.DashboardComponent,
      ),
    data: { role: "patient" },
  },
  {
    path: "secretary/patient-referrals",
    canActivate: [authGuard, roleGuard(["secretary"])],
    loadComponent: () => import("./pages/secretary-dashboard/secretary-dashboard.component").then(m => m.SecretaryDashboardComponent),
    data: { role: "secretary", initialSection: "patientReferrals" },
  },
  {
    path: "admin/patient-referrals",
    canActivate: [authGuard, roleGuard(["admin"])],
    loadComponent: () => import("./pages/dashboard/dashboard.component").then(m => m.DashboardComponent),
    data: { role: "admin", initialSection: "patientReferrals" },
  },
  {
    path: "**",
    loadComponent: () =>
      import("./pages/not-found/not-found.component").then(
        (m) => m.NotFoundComponent,
      ),
  },
];
