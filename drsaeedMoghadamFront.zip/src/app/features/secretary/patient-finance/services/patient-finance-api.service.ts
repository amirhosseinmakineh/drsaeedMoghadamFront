import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { map, Observable } from "rxjs";
import { AuthService } from "../../../../core/auth/auth.service";
import { environment } from "../../../../../environments/environment";
import { ApiResult, CreateChequeRequest, CreateFinancialCaseRequest, CreatePromissoryNoteRequest, IdResponse, PageQuery, PaginatedResult, PatientCheque, PatientDebt, PatientFinancialCase, PatientFinancialCaseDetails, PatientFinancialCaseId, PatientFinancialCaseIdResponse, PatientFinancialCaseSummary, PatientFinancialCommitment, PatientFinancialTransaction, PatientPromissoryNote, UpdateChequeRequest, UpdateFinancialCaseRequest, UpdatePromissoryNoteRequest } from "../models/patient-finance.models";

@Injectable({ providedIn: "root" })
export class PatientFinanceApiService {
  private readonly baseUrl = `${environment.apiBaseUrl}/secretary`;
  constructor(private readonly http: HttpClient, private readonly auth: AuthService) {}
  private options(query: PageQuery = {}) {
    const token = this.auth.user()?.token;
    return {
      headers: token ? new HttpHeaders({ Authorization: `Bearer ${token}` }) : new HttpHeaders(),
      params: this.params(query),
    };
  }
  private params(query: PageQuery = {}): HttpParams {
    let params = new HttpParams();
    Object.entries(query).forEach(([key, value]) => {
      if (value !== null && value !== undefined && value !== "") params = params.set(key, String(value));
    });
    return params;
  }
  getCases(query: PageQuery) { return this.get<PaginatedResult<PatientFinancialCase>>(`${this.baseUrl}/patient-financial-cases`, query); }
  getCase(id: PatientFinancialCaseId) { return this.get<PatientFinancialCaseDetails>(`${this.baseUrl}/patient-financial-cases/${id}`); }
  getCaseSummary(id: PatientFinancialCaseId) { return this.get<PatientFinancialCaseSummary>(`${this.baseUrl}/patient-financial-cases/${id}/summary`); }
  createCase(body: CreateFinancialCaseRequest) { return this.http.post<ApiResult<PatientFinancialCaseIdResponse>>(`${this.baseUrl}/patient-financial-cases`, body, this.options()); }
  updateCase(id: PatientFinancialCaseId, body: UpdateFinancialCaseRequest) { return this.http.put<ApiResult<PatientFinancialCaseIdResponse>>(`${this.baseUrl}/patient-financial-cases/${id}`, body, this.options()); }
  cancelCase(id: PatientFinancialCaseId) { return this.http.delete<ApiResult<PatientFinancialCaseIdResponse>>(`${this.baseUrl}/patient-financial-cases/${id}`, this.options()); }
  uploadGuaranteeDocument(id: PatientFinancialCaseId, file: File): Observable<ApiResult<PatientFinancialCaseIdResponse>> {
    const token = this.auth.user()?.token;
    const headers = token ? new HttpHeaders({ Authorization: `Bearer ${token}` }) : new HttpHeaders();
    const body = new FormData();
    body.append("file", file);
    return this.http.post<ApiResult<PatientFinancialCaseIdResponse>>(`${this.baseUrl}/patient-financial-cases/${id}/guarantee-document`, body, { headers });
  }
  deleteGuaranteeDocument(id: PatientFinancialCaseId) { return this.http.delete<ApiResult<PatientFinancialCaseIdResponse>>(`${this.baseUrl}/patient-financial-cases/${id}/guarantee-document`, this.options()); }
  addCheque(caseId: PatientFinancialCaseId, body: CreateChequeRequest) { return this.http.post<ApiResult<IdResponse>>(`${this.baseUrl}/patient-financial-cases/${caseId}/cheques`, body, this.options()); }
  addPromissoryNote(caseId: PatientFinancialCaseId, body: CreatePromissoryNoteRequest) { return this.http.post<ApiResult<IdResponse>>(`${this.baseUrl}/patient-financial-cases/${caseId}/promissory-notes`, body, this.options()); }
  getCheques(query: PageQuery) { return this.get<PaginatedResult<PatientCheque>>(`${this.baseUrl}/patient-cheques`, query); }
  updateCheque(id: number, body: UpdateChequeRequest) { return this.http.put<ApiResult<IdResponse>>(`${this.baseUrl}/patient-cheques/${id}`, body, this.options()); }
  deleteCheque(id: number) { return this.http.delete<ApiResult<IdResponse>>(`${this.baseUrl}/patient-cheques/${id}`, this.options()); }
  updateChequeStatus(id: number, status: 2 | 3 | 4) { return this.http.put<ApiResult<IdResponse>>(`${this.baseUrl}/patient-cheques/${id}/status`, { status }, this.options()); }
  getPromissoryNotes(query: PageQuery) { return this.get<PaginatedResult<PatientPromissoryNote>>(`${this.baseUrl}/patient-promissory-notes`, query); }
  updatePromissoryNote(id: number, body: UpdatePromissoryNoteRequest) { return this.http.put<ApiResult<IdResponse>>(`${this.baseUrl}/patient-promissory-notes/${id}`, body, this.options()); }
  deletePromissoryNote(id: number) { return this.http.delete<ApiResult<IdResponse>>(`${this.baseUrl}/patient-promissory-notes/${id}`, this.options()); }
  updatePromissoryNoteStatus(id: number, status: 2 | 3 | 4) { return this.http.put<ApiResult<IdResponse>>(`${this.baseUrl}/patient-promissory-notes/${id}/status`, { status }, this.options()); }
  getDebts(query: PageQuery) { return this.get<PaginatedResult<PatientDebt>>(`${this.baseUrl}/patient-debts`, query); }
  payDebt(id: number) { return this.http.post<ApiResult<IdResponse>>(`${this.baseUrl}/patient-debts/${id}/pay`, null, this.options()); }
  getTransactions(query: PageQuery) { return this.get<PaginatedResult<PatientFinancialTransaction>>(`${this.baseUrl}/patient-financial-transactions`, query); }
  getDueCommitments(query: PageQuery) { return this.get<PaginatedResult<PatientFinancialCommitment>>(`${this.baseUrl}/patient-financial-commitments/due`, query); }

  private get<T>(url: string, query: PageQuery = {}): Observable<T> {
    return this.http.get<T | ApiResult<T>>(url, this.options(query)).pipe(
      map(response => {
        if (this.isApiResult(response)) {
          if (!response.isSuccess || response.data === null) {
            throw new Error(response.message || "دریافت اطلاعات مالی انجام نشد.");
          }
          return response.data;
        }
        return response;
      }),
    );
  }

  private isApiResult<T>(response: T | ApiResult<T>): response is ApiResult<T> {
    return typeof response === "object" && response !== null && "isSuccess" in response && "data" in response;
  }
}
