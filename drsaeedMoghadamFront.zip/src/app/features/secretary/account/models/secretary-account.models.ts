import { FinancialTransactionType } from "../enums/financial-transaction-type.enum";
import { PaymentMethod } from "../enums/payment-method.enum";

export interface ApiResponse<T> {
  isSuccess: boolean;
  message: string;
  data: T;
}

export interface CreateSecretaryFinancialTransactionRequest {
  type: FinancialTransactionType;
  amount: number;
  transactionDate: string;
  subject: string | null;
  counterpartyName: string | null;
  paymentMethod: PaymentMethod;
  description: string | null;
  expenseCategoryId: number | null;
}

export interface GetSecretaryFinancialTransactionsRequest {
  type?: FinancialTransactionType;
  fromDate?: string;
  toDate?: string;
  search?: string;
  expenseCategoryId?: number;
  page: number;
  pageSize: number;
}

export type SecretaryTransactionFilters = Omit<
  GetSecretaryFinancialTransactionsRequest,
  "page" | "pageSize"
>;

export interface SecretaryFinancialTransactionDto {
  id: number;
  type: FinancialTransactionType;
  typeTitle: string;
  amount: number;
  transactionDate: string;
  subject: string | null;
  counterpartyName: string | null;
  paymentMethod: PaymentMethod;
  paymentMethodTitle: string;
  description: string | null;
  expenseCategoryId: number | null;
  expenseCategoryTitle: string | null;
  createdAt: string;
  updatedAt: string | null;
}

export interface SecretaryFinancialTransactionListDto {
  items: SecretaryFinancialTransactionDto[];
  page: number;
  pageSize: number;
  totalCount: number;
}

export interface SecretaryFinancialSummaryDto {
  totalIncome: number;
  totalExpense: number;
  balance: number;
  incomeCount: number;
  expenseCount: number;
}

export interface SecretaryExpenseCategoryDto {
  id: number;
  title: string;
}

export interface SecretaryExpenseCategoryManagementDto extends SecretaryExpenseCategoryDto {
  isActive: boolean;
  createdAt: string;
  updatedAt: string | null;
}

export interface SaveSecretaryExpenseCategoryRequest {
  title: string;
  isActive: boolean;
}

export interface CreatedTransactionDto {
  id: number;
}

export type UpdateSecretaryFinancialTransactionRequest = CreateSecretaryFinancialTransactionRequest;
